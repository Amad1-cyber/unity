﻿using UnityEngine;
using UnityEngine.AI;
using System.Collections;
using FPSRetroKit; // Adjust if necessary

public enum EnemyType
{
    Devil,
    Undead,
    Goblin,
    Boss,
    Other
}

public class EnemyAI_3D : MonoBehaviour
{
    [Header("Enemy Identification")]
    public EnemyType enemyType = EnemyType.Other;

    [Header("Enemy Stats")]
    public int maxHealth = 200;
    private int currentHealth;

    [Header("Defense Settings")]
    public int enemyDefense = 10;

    [Header("Experience Reward")]
    public float xpReward = 50f;
    private bool xpAwarded = false;

    [Header("Combat Settings")]
    public float chaseRange = 20f;
    public float assaultRange = 2.5f;
    public float attackCooldown = 1.5f;
    private float lastAttackTime;
    public int assaultDamage = 20;

    [Header("Movement Settings")]
    public float speed = 3.5f;
    public Transform playerTarget;
    private NavMeshAgent agent;

    [Header("Effects & Animation")]
    public GameObject deathEffect;
    public AudioClip deathSound;
    public AudioClip gotHitSound; // Got hit sound
    private AudioSource audioSource;
    public Animator animator;

    [Header("Boss Specific Settings")]
    public GameObject chalicePrefab;
    public Transform chaliceSpawnPoint;

    // Taming and ally behavior omitted for brevity

    void Start()
    {
        currentHealth = maxHealth;
        agent = GetComponent<NavMeshAgent>();
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
            audioSource = gameObject.AddComponent<AudioSource>();
        if (agent != null)
            agent.speed = speed;
        if (playerTarget == null)
        {
            GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null)
                playerTarget = playerObj.transform;
        }
    }

    void Update()
    {
        if (playerTarget == null)
            return;

        float distanceToPlayer = Vector3.Distance(transform.position, playerTarget.position);
        if (distanceToPlayer <= assaultRange)
            AssaultPlayer();
        else if (distanceToPlayer <= chaseRange)
            ChasePlayer();
        else
            Idle();
    }

    void ChasePlayer()
    {
        if (animator != null)
            animator.SetBool("isRunning", true);
        if (agent != null)
            agent.SetDestination(playerTarget.position);
        FaceTarget(playerTarget);
    }

    void Idle()
    {
        if (animator != null)
            animator.SetBool("isRunning", false);
        if (agent != null)
            agent.ResetPath();
    }

    void AssaultPlayer()
    {
        if (Time.time - lastAttackTime >= attackCooldown)
        {
            lastAttackTime = Time.time;
            FaceTarget(playerTarget);
            if (animator != null)
                animator.SetTrigger("Attack");

            PlayerHealth pHealth = playerTarget.GetComponent<PlayerHealth>();
            if (pHealth != null)
                pHealth.TakeDamage(assaultDamage);
        }
    }

    void FaceTarget(Transform target)
    {
        if (target == null)
            return;
        Vector3 direction = (target.position - transform.position).normalized;
        direction.y = 0;
        transform.rotation = Quaternion.LookRotation(direction);
    }

    public void TakeDamage(int damage)
    {
        // Calculate effective damage.
        int effectiveDamage = damage - enemyDefense;
        if (effectiveDamage < 1)
            effectiveDamage = 1;
        currentHealth -= effectiveDamage;
        if (animator != null)
            animator.SetTrigger("TakeDamage");

        Debug.Log($"{gameObject.name} took {effectiveDamage} damage. HP: {currentHealth}/{maxHealth}");

        // Play got hit sound.
        if (gotHitSound != null)
            audioSource.PlayOneShot(gotHitSound);

        // Optionally, spawn a damage popup if you have one (similar to player).
        // (You can add code here if you have a damagePopupPrefab reference.)

        if (currentHealth <= 0)
        {
            if (!xpAwarded)
            {
                xpAwarded = true;
                GivePlayerXP();
                NotifyQuestManager();
            }
            StartCoroutine(Vanquish());
        }
    }

    private IEnumerator Vanquish()
    {
        if (animator != null)
            animator.SetTrigger("Die");
        if (agent != null)
            agent.isStopped = true;
        if (deathEffect != null)
            Instantiate(deathEffect, transform.position, Quaternion.identity);
        if (deathSound != null && audioSource != null)
            audioSource.PlayOneShot(deathSound);
        yield return new WaitForSeconds(2f);
        if (enemyType == EnemyType.Boss)
            ActivateChalice();
        Destroy(gameObject);
    }

    private void GivePlayerXP()
    {
        if (playerTarget == null)
            return;
        PlayerHealth pHealth = playerTarget.GetComponent<PlayerHealth>();
        if (pHealth != null)
        {
            Debug.Log($"{enemyType} defeated! Awarding {xpReward} XP.");
            pHealth.AddExperience(xpReward);
        }
    }

    private void NotifyQuestManager()
    {
        QuestManager questManager = FindObjectOfType<QuestManager>();
        if (questManager != null)
            questManager.OnDevilDefeated(gameObject);
    }

    private void ActivateChalice()
    {
        if (chalicePrefab != null && chaliceSpawnPoint != null)
        {
            Instantiate(chalicePrefab, chaliceSpawnPoint.position, chaliceSpawnPoint.rotation);
            Debug.Log("Boss defeated! A chalice has appeared by the tree...");
            if (NotificationUI.Instance != null)
                NotificationUI.Instance.ShowNotification("A chalice has appeared by the tree...", 4f);
        }
        else
        {
            Debug.LogWarning("Chalice prefab or spawn point not assigned!");
        }
    }
}
