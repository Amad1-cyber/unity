using UnityEngine;
using UnityEngine.AI;

namespace FPSRetroKit
{
    public class TameableEnemy : MonoBehaviour
    {
        [Header("Health Settings")]
        public int maxHealth = 100;
        private int currentHealth;

        [Header("Taming Settings")]
        [Tooltip("Indicates whether this enemy can be tamed.")]
        public bool canBeTamed = false;
        [Tooltip("Indicates whether this enemy has been tamed.")]
        public bool isTamed = false;
        [Tooltip("Chance (0 to 1) that a taming attempt is successful.")]
        public float tameSuccessChance = 0.5f;
        [Tooltip("Range within which taming can be attempted.")]
        public float tameRange = 3f;
        [Tooltip("Animation trigger for taming success.")]
        public string tameTriggerName = "Tamed";
        [Tooltip("Sound to play on successful taming.")]
        public AudioClip tameSuccessSound;
        [Tooltip("Particle effect prefab for taming success.")]
        public GameObject tameParticleEffectPrefab;

        [Header("Ally Behavior Settings")]
        [Tooltip("Speed at which the tamed enemy follows the player.")]
        public float allyFollowSpeed = 3.5f;
        [Tooltip("Distance at which the tamed enemy stops following its target.")]
        public float followStoppingDistance = 2f;
        [Tooltip("Range within which the tamed enemy can attack an opposing enemy.")]
        public float allyAttackRange = 2f;
        [Tooltip("Time in seconds between ally attacks.")]
        public float allyAttackCooldown = 1.5f;
        [Tooltip("Damage dealt by the tamed enemy when attacking opposing foes.")]
        public int allyDamage = 20;
        private float lastAllyAttackTime = 0f;

        [Header("References")]
        [Tooltip("Reference to the NavMeshAgent component.")]
        private NavMeshAgent agent;
        [Tooltip("Reference to the Animator component.")]
        private Animator animator;
        [Tooltip("Reference to the AudioSource component.")]
        private AudioSource audioSource;
        [Tooltip("Reference to the player that this enemy will follow as an ally.")]
        public Transform playerToFollow;

        void Start()
        {
            currentHealth = maxHealth;
            agent = GetComponent<NavMeshAgent>();
            animator = GetComponent<Animator>();
            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
                audioSource = gameObject.AddComponent<AudioSource>();

            // Auto-find the player if not assigned.
            if (playerToFollow == null)
            {
                GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
                if (playerObj != null)
                    playerToFollow = playerObj.transform;
            }
        }

        /// <summary>
        /// Attempt to tame the enemy.
        /// </summary>
        public void TameEnemy()
        {
            if (!canBeTamed)
            {
                Debug.Log($"{gameObject.name} cannot be tamed.");
                return;
            }
            if (isTamed)
            {
                Debug.Log($"{gameObject.name} is already tamed.");
                return;
            }

            float roll = Random.value;
            if (roll <= tameSuccessChance)
            {
                isTamed = true;
                currentHealth = maxHealth; // Restore full health on taming
                Debug.Log($"{gameObject.name} has been successfully tamed!");

                // Stop current hostile behavior.
                if (agent != null)
                    agent.ResetPath();

                // Change tag to "Ally" so it no longer attacks the player.
                gameObject.tag = "Ally";

                // Play tame animation.
                if (animator != null && !string.IsNullOrEmpty(tameTriggerName))
                    animator.SetTrigger(tameTriggerName);

                // Play tame success sound.
                if (tameSuccessSound != null)
                    audioSource.PlayOneShot(tameSuccessSound);

                // Spawn particle effect.
                if (tameParticleEffectPrefab != null)
                {
                    GameObject effect = Instantiate(tameParticleEffectPrefab, transform.position, Quaternion.identity);
                    Destroy(effect, 3f);
                }
            }
            else
            {
                Debug.Log($"{gameObject.name} taming attempt failed.");
            }
        }

        /// <summary>
        /// Apply damage to this enemy.
        /// </summary>
        public void TakeDamage(int damage)
        {
            // Tamed enemy still can take damage (or you can reduce or ignore damage)
            int effectiveDamage = damage; // You can factor in defense here if desired.
            currentHealth -= effectiveDamage;
            Debug.Log($"{gameObject.name} took {effectiveDamage} damage. HP: {currentHealth}/{maxHealth}");

            if (animator != null)
                animator.SetTrigger("TakeDamage");

            if (currentHealth <= 0)
                Die();
        }

        void Die()
        {
            Debug.Log($"{gameObject.name} has died.");
            Destroy(gameObject);
        }

        void Update()
        {
            // If not tamed, execute normal enemy behavior (chase/attack player) here.
            if (!isTamed)
            {
                // Normal hostile AI logic would be here.
                return;
            }

            // Tamed enemy behavior (ally):
            // Look for opposing enemy targets (tagged "Enemy") to attack.
            Transform targetFoe = FindNearestOpposingEnemy();

            if (targetFoe != null)
            {
                // Set destination to foe.
                if (agent != null)
                    agent.SetDestination(targetFoe.position);

                // If foe is within attack range and cooldown is over, attack it.
                if (Vector3.Distance(transform.position, targetFoe.position) <= allyAttackRange &&
                    Time.time - lastAllyAttackTime >= allyAttackCooldown)
                {
                    AttackTarget(targetFoe);
                    lastAllyAttackTime = Time.time;
                }
            }
            else if (playerToFollow != null)
            {
                // If no foe is found, follow the player.
                if (agent != null)
                    agent.SetDestination(playerToFollow.position);
            }
        }

        /// <summary>
        /// Finds the nearest opposing enemy (with tag "Enemy").
        /// </summary>
        Transform FindNearestOpposingEnemy()
        {
            GameObject[] foes = GameObject.FindGameObjectsWithTag("Enemy");
            Transform nearest = null;
            float minDistance = Mathf.Infinity;
            foreach (GameObject foe in foes)
            {
                // Skip foes that are already tamed or allies.
                TameableEnemy tameComponent = foe.GetComponent<TameableEnemy>();
                if (tameComponent != null && tameComponent.isTamed)
                    continue;

                float dist = Vector3.Distance(transform.position, foe.transform.position);
                if (dist < minDistance)
                {
                    minDistance = dist;
                    nearest = foe.transform;
                }
            }
            return nearest;
        }

        /// <summary>
        /// Attacks the target foe by sending it damage.
        /// </summary>
        void AttackTarget(Transform target)
        {
            Debug.Log($"{gameObject.name} (ally) attacks {target.gameObject.name} for {allyDamage} damage.");
            target.gameObject.SendMessage("TakeDamage", allyDamage, SendMessageOptions.DontRequireReceiver);
            // Optionally, trigger an attack animation for the ally here.
        }
    }
}
