using UnityEngine;
using Mirror;

public class NetworkKeyBindings : MonoBehaviour
{
    private NetworkManager networkManager;

    void Start()
    {
        // Try to get the singleton instance of the NetworkManager.
        networkManager = NetworkManager.singleton;
        if (networkManager == null)
        {
            Debug.LogError("No NetworkManager found in the scene. Please add one.");
        }
    }

    void Update()
    {
        // Press H for Host (server + client)
        if (Input.GetKeyDown(KeyCode.H))
        {
            if (!NetworkClient.isConnected && !NetworkServer.active)
            {
                Debug.Log("Starting Host (Server + Client)...");
                networkManager.StartHost();
            }
        }
        // Press S for Server Only
        else if (Input.GetKeyDown(KeyCode.S))
        {
            if (!NetworkServer.active)
            {
                Debug.Log("Starting Server Only...");
                networkManager.StartServer();
            }
        }
        // Press C for Client Only
        else if (Input.GetKeyDown(KeyCode.C))
        {
            if (!NetworkClient.isConnected)
            {
                Debug.Log("Starting Client Only...");
                networkManager.StartClient();
            }
        }
    }
}
