﻿using UnityEngine;

namespace FPSRetroKit
{
    public class PlayerMovement : MonoBehaviour
    {
        [Header("Movement Settings")]
        public float playerWalkingSpeed = 5f;
        public float jumpStrength = 10f;

        [Header("Mouse Look Settings")]
        public float mouseSensitivity = 2f; // Adjust sensitivity
        public Transform playerCamera; // Assign the camera in the inspector
        public float verticalRotationLimit = 80f; // Max up/down camera rotation

        private CharacterController cc;
        private float verticalVelocity;
        private float verticalRotation = 0f; // To track up/down camera rotation

        void Start()
        {
            cc = GetComponent<CharacterController>();
            Cursor.lockState = CursorLockMode.Locked; // Lock cursor to center of screen
            Cursor.visible = false; // Hide cursor
        }

        void Update()
        {
            HandleMovement();
            HandleMouseLook();
        }

        private void HandleMovement()
        {
            float moveHorizontal = Input.GetAxis("Horizontal") * playerWalkingSpeed;
            float moveVertical = Input.GetAxis("Vertical") * playerWalkingSpeed;

            if (cc.isGrounded)
            {
                verticalVelocity = -0.1f;

                if (Input.GetButtonDown("Jump"))
                {
                    verticalVelocity = jumpStrength;
                }
            }
            else
            {
                verticalVelocity += Physics.gravity.y * Time.deltaTime;
            }

            Vector3 moveDirection = new Vector3(moveHorizontal, verticalVelocity, moveVertical);
            cc.Move(transform.TransformDirection(moveDirection) * Time.deltaTime);
        }

        private void HandleMouseLook()
        {
            if (Input.GetMouseButton(1)) // Right mouse button held
            {
                // Get mouse input
                float horizontalRotation = Input.GetAxis("Mouse X") * mouseSensitivity;
                float verticalInput = Input.GetAxis("Mouse Y") * mouseSensitivity;

                // Apply horizontal rotation to player
                transform.Rotate(0, horizontalRotation, 0);

                // Apply vertical rotation (clamp to prevent over-rotation)
                verticalRotation -= verticalInput;
                verticalRotation = Mathf.Clamp(verticalRotation, -verticalRotationLimit, verticalRotationLimit);
                playerCamera.localRotation = Quaternion.Euler(verticalRotation, 0, 0);
            }
        }
    }
}
