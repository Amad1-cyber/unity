using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class NotificationUI : MonoBehaviour
{
    public static NotificationUI Instance;

    [Header("Notification Settings")]
    public Text notificationText;   // Assign a Text component from your Canvas
    public float displayDuration = 4f;  // How long to display the message

    void Awake()
    {
        // Singleton pattern to easily access the UI from other scripts
        if (Instance == null)
        {
            Instance = this;
            // Optionally: DontDestroyOnLoad(gameObject); if you want persistence across scenes
        }
        else
        {
            Destroy(gameObject);
        }
    }

    /// <summary>
    /// Displays the notification text on screen for a set duration.
    /// </summary>
    public void ShowNotification(string message, float duration)
    {
        StopAllCoroutines();
        if (notificationText != null)
        {
            notificationText.text = message;
            notificationText.gameObject.SetActive(true);
            StartCoroutine(HideNotificationAfter(duration));
        }
        else
        {
            Debug.LogWarning("NotificationUI: notificationText is not assigned!");
        }
    }

    private IEnumerator HideNotificationAfter(float duration)
    {
        yield return new WaitForSeconds(duration);
        if (notificationText != null)
        {
            notificationText.text = "";
            notificationText.gameObject.SetActive(false);
        }
    }
}
