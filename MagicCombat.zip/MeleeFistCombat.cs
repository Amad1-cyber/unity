using System.Collections;
using UnityEngine;

public class MeleeFistCombat : MonoBehaviour
{
    [Header("Fist Sprite Setup")]
    [Tooltip("SpriteRenderer for the first-person fists.")]
    public SpriteRenderer fistRenderer;

    [Tooltip("Idle sprite for the fists when not punching.")]
    public Sprite idleSprite;

    [Tooltip("Array of sprites for the punch animation flipbook.")]
    public Sprite[] punchSprites;

    [Tooltip("Time (in seconds) each punch frame is displayed.")]
    public float punchFrameRate = 0.1f;

    [Header("Input Settings")]
    [Tooltip("Key used to trigger a melee punch.")]
    public KeyCode punchKey = KeyCode.X;

    [Header("Melee Damage Settings")]
    public int meleeDamage = 40;
    public float meleeRange = 2.5f;

    [Tooltip("Delay (in seconds) after the final punch frame before applying damage.")]
    public float punchDamageDelay = 0.0f;

    [Tooltip("Camera used for the melee raycast (if null, defaults to Camera.main).")]
    public Camera playerCamera;

    [Header("Audio Settings")]
    [Tooltip("Punch sound effect to play when punching.")]
    public AudioClip punchSound;

    private AudioSource audioSource;
    private bool isPunching = false;

    void Start()
    {
        // Use the main camera if no camera assigned.
        if (playerCamera == null)
            playerCamera = Camera.main;

        // Set idle sprite at start.
        if (fistRenderer != null && idleSprite != null)
        {
            fistRenderer.sprite = idleSprite;
        }

        // Get or add an AudioSource.
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
            audioSource = gameObject.AddComponent<AudioSource>();
    }

    void Update()
    {
        // Trigger punch on key press if not already punching.
        if (Input.GetKeyDown(punchKey) && !isPunching)
        {
            StartCoroutine(PerformPunch());
        }
    }

    private IEnumerator PerformPunch()
    {
        isPunching = true;

        // Play the punch sound once at the start.
        if (punchSound != null)
            audioSource.PlayOneShot(punchSound);

        // Animate the punch flipbook.
        if (punchSprites != null && punchSprites.Length > 0 && fistRenderer != null)
        {
            for (int i = 0; i < punchSprites.Length; i++)
            {
                fistRenderer.sprite = punchSprites[i];
                // If you prefer to play a sound on every frame (commented out to avoid spamming):
                // if (punchSound != null) audioSource.PlayOneShot(punchSound);
                yield return new WaitForSeconds(punchFrameRate);
            }
        }
        else
        {
            yield return new WaitForSeconds(0.2f);
        }

        if (punchDamageDelay > 0f)
            yield return new WaitForSeconds(punchDamageDelay);

        // Raycast to apply damage.
        ApplyMeleeDamage();

        // Return to idle sprite.
        if (fistRenderer != null && idleSprite != null)
            fistRenderer.sprite = idleSprite;

        isPunching = false;
    }

    private void ApplyMeleeDamage()
    {
        // Raycast from the center of the screen.
        Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
        if (Physics.Raycast(ray, out RaycastHit hit, meleeRange))
        {
            if (hit.collider.CompareTag("Enemy"))
            {
                Debug.Log("Melee hit " + hit.collider.gameObject.name + " for " + meleeDamage + " damage.");
                // Send message to the enemy to apply damage.
                hit.collider.gameObject.SendMessage("TakeDamage", meleeDamage, SendMessageOptions.DontRequireReceiver);
            }
        }
    }
}
