using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public class RPGUIManager : MonoBehaviour
    {
        [Header("UI Elements")]
        public Text healthText;
        public Text armorText;
        public Text levelText;
        public Text scoreText;

        [Header("Player Stats")]
        public int playerHealth = 100;
        public int maxHealth = 100;
        public int playerArmor = 50;
        public int maxArmor = 50;
        public int playerLevel = 1;
        public float playerXP = 0f;
        public float xpToLevelUp = 100f;

        void Start()
        {
            UpdateUI();
        }

        void UpdateUI()
        {
            healthText.text = $"Health: {playerHealth}/{maxHealth}";
            armorText.text = $"Armor: {playerArmor}/{maxArmor}";
            levelText.text = $"Level: {playerLevel}";
            scoreText.text = $"XP: {playerXP} / {xpToLevelUp}";
        }

        public void TakeDamage(int damage)
        {
            if (playerArmor > 0)
            {
                playerArmor -= damage;
                if (playerArmor < 0) playerArmor = 0;
            }
            else
            {
                playerHealth -= damage;
                if (playerHealth < 0) playerHealth = 0;
            }
            UpdateUI();
        }

        public void AddExperience(float xp)
        {
            playerXP += xp;
            if (playerXP >= xpToLevelUp)
            {
                LevelUp();
            }
            UpdateUI();
        }

        void LevelUp()
        {
            playerLevel++;
            playerXP = 0;
            xpToLevelUp *= 1.5f;
            maxHealth += 20;
            playerHealth = maxHealth;
            maxArmor += 10;
            playerArmor = maxArmor;
            Debug.Log("Level Up!");
        }
    }
}
