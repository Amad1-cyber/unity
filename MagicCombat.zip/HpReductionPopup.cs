using UnityEngine;
using UnityEngine.UI;

public class HPReductionPopup : MonoBehaviour
{
    [Header("Popup Components")]
    public Text popupText;              // The UI Text component to display the HP reduction equation.
    public CanvasGroup canvasGroup;     // The CanvasGroup for controlling the popup's alpha.

    [Header("Popup Settings")]
    public float moveUpSpeed = 100f;      // Speed at which the popup moves upward.
    public float displayDuration = 0.5f;  // Time before fade begins.
    public float fadeDuration = 1f;       // Time for the popup to fully fade out.

    private float timer = 0f;

    void Update()
    {
        // Move the popup upward.
        transform.Translate(Vector3.up * moveUpSpeed * Time.deltaTime);

        timer += Time.deltaTime;
        if (timer >= displayDuration)
        {
            if (canvasGroup != null)
            {
                canvasGroup.alpha -= Time.deltaTime / fadeDuration;
                if (canvasGroup.alpha <= 0f)
                    Destroy(gameObject);
            }
            else if (popupText != null)
            {
                Color c = popupText.color;
                c.a -= Time.deltaTime / fadeDuration;
                popupText.color = c;
                if (c.a <= 0f)
                    Destroy(gameObject);
            }
        }
    }

    /// <summary>
    /// Sets the popup text to display the HP reduction equation.
    /// For example: "100 - 20 = 80"
    /// </summary>
    public void SetHPReduction(int oldHP, int damage, int newHP)
    {
        if (popupText != null)
            popupText.text = $"{oldHP} - {damage} = {newHP}";
        timer = 0f;
        if (canvasGroup != null)
            canvasGroup.alpha = 1f;
    }
}
