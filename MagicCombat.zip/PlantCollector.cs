using UnityEngine;

namespace FPSRetroKit
{
    public class PlantCollector : MonoBehaviour
    {
        public static PlantCollector Instance { get; private set; }

        [Header("Plant Collection Settings")]
        public int plantCount = 0;

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        public void AddPlant()
        {
            plantCount++;
            Debug.Log($"Plant collected: {plantCount}");
        }

        public bool HasEnoughPlants(int required)
        {
            return plantCount >= required;
        }

        public void ResetPlants()
        {
            plantCount = 0;
        }
    }
}
