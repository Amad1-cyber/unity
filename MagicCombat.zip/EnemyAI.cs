using UnityEngine;
using UnityEngine.AI;
using FPSRetroKit; // Ensure this matches your namespace

public class EnemyAI : MonoBehaviour
{
    [Header("Enemy Stats")]
    public int maxHealth = 100;
    private int currentHealth;

    [Header("Combat Settings")]
    public float attackRange = 2f;
    public float attackCooldown = 2f;
    private float lastAttackTime;
    public int attackDamage = 10;

    [Header("Chase Settings")]
    public float chaseRange = 15f;
    public float speed = 3.5f;

    private Transform player;
    private NavMeshAgent agent;
    private Animator animator; // For animations

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player")?.transform;
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>(); // Ensure your enemy has an Animator

        agent.speed = speed;
        currentHealth = maxHealth;
    }

    void Update()
    {
        if (player == null) return;

        float distance = Vector3.Distance(transform.position, player.position);

        if (distance <= attackRange)
        {
            AttackPlayer();
        }
        else if (distance <= chaseRange)
        {
            ChasePlayer();
        }
        else
        {
            Idle();
        }
    }

    void ChasePlayer()
    {
        agent.SetDestination(player.position);
        animator.SetBool("isWalking", true);
        animator.SetBool("isAttacking", false);
    }

    void AttackPlayer()
    {
        if (Time.time - lastAttackTime >= attackCooldown)
        {
            lastAttackTime = Time.time;
            PlayerHealth playerHealth = player.GetComponent<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.TakeDamage(attackDamage);
            }

            animator.SetBool("isAttacking", true);
            animator.SetBool("isWalking", false);
        }
    }

    void Idle()
    {
        animator.SetBool("isWalking", false);
        animator.SetBool("isAttacking", false);
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Debug.Log("Enemy has been defeated!");
        animator.SetTrigger("Die");
        agent.isStopped = true;
        Destroy(gameObject, 2f); // Delay destruction for animation
    }
}
