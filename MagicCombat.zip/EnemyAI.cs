using UnityEngine;
using UnityEngine.AI;

namespace FPSRetroKit
{
    public class EnemyAI : MonoBehaviour
    {
        [Header("Enemy Stats")]
        public int health = 100;
        public int damage = 10;
        public float attackRange = 2f;
        public float attackCooldown = 2f;
        public float searchRadius = 10f;
        public float tameSuccessChance = 0.5f;

        private Transform player;
        private PlayerHealth playerHealth;
        private NavMeshAgent navAgent;
        private bool isDead = false;
        private bool isTamed = false;
        private float lastAttackTime = 0f;

        private GameObject[] enemiesInScene;
        private GameObject currentTarget;

        void Start()
        {
            navAgent = GetComponent<NavMeshAgent>();

            if (navAgent == null)
            {
                UnityEngine.Debug.LogError("NavMeshAgent component is missing on this enemy.");
            }

            GameObject playerObject = GameObject.FindGameObjectWithTag("Player");

            if (playerObject != null)
            {
                player = playerObject.transform;
                playerHealth = playerObject.GetComponent<PlayerHealth>();

                if (playerHealth == null)
                {
                    UnityEngine.Debug.LogError("PlayerHealth component not found on Player object.");
                }
            }
            else
            {
                UnityEngine.Debug.LogError("Player not found in the scene. Ensure the player has a 'Player' tag.");
            }
        }

        void Update()
        {
            if (isDead || player == null || playerHealth == null || navAgent == null) return;

            if (Input.GetKeyDown(KeyCode.T) && !isTamed && IsPlayerNear())
            {
                TryToTameEnemy();
            }

            if (isTamed)
            {
                HandleTamedBehavior();
            }
            else
            {
                HandleAggressiveBehavior();
            }
        }

        private void HandleAggressiveBehavior()
        {
            navAgent.SetDestination(player.position);

            if (Vector3.Distance(transform.position, player.position) <= attackRange)
            {
                if (Time.time >= lastAttackTime + attackCooldown)
                {
                    AttackPlayer();
                    lastAttackTime = Time.time;
                }
            }
        }

        private void HandleTamedBehavior()
        {
            SearchForEnemies();

            if (currentTarget != null)
            {
                navAgent.SetDestination(currentTarget.transform.position);

                if (Vector3.Distance(transform.position, currentTarget.transform.position) <= attackRange)
                {
                    if (Time.time >= lastAttackTime + attackCooldown)
                    {
                        AttackTarget(currentTarget);
                        lastAttackTime = Time.time;
                    }
                }
            }
            else
            {
                navAgent.SetDestination(player.position);
            }
        }

        public void TakeDamage(int damageAmount)
        {
            if (isDead) return;

            health -= damageAmount;
            UnityEngine.Debug.Log($"Enemy took {damageAmount} damage. Remaining health: {health}");

            if (health <= 0)
            {
                Die();
            }
        }

        private void AttackPlayer()
        {
            if (playerHealth != null)
            {
                UnityEngine.Debug.Log("Enemy attacks the player!");
                playerHealth.TakeDamage(damage);
            }
        }

        private void AttackTarget(GameObject target)
        {
            EnemyAI targetEnemy = target.GetComponent<EnemyAI>();
            if (targetEnemy != null)
            {
                UnityEngine.Debug.Log("Tamed enemy attacks another enemy!");
                targetEnemy.TakeDamage(damage);
            }
        }

        private void Die()
        {
            isDead = true;

            if (navAgent != null)
            {
                navAgent.isStopped = true;
            }

            UnityEngine.Debug.Log("Enemy defeated!");

            if (playerHealth != null)
            {
                playerHealth.AddExperience(50f);
            }

            Destroy(gameObject, 2f);
        }

        public void TryToTameEnemy()
        {
            if (isDead || isTamed) return;

            float randomChance = UnityEngine.Random.value;
            if (randomChance <= tameSuccessChance)
            {
                TameEnemy();
            }
            else
            {
                UnityEngine.Debug.Log("Taming attempt failed.");
            }
        }

        private void TameEnemy()
        {
            isTamed = true;
            UnityEngine.Debug.Log("Enemy has been tamed and will now fight for the player!");
        }

        public void ReleaseTame()
        {
            if (isDead || !isTamed) return;

            isTamed = false;
            UnityEngine.Debug.Log("Enemy is no longer tamed and is hostile again.");
        }

        private void SearchForEnemies()
        {
            enemiesInScene = GameObject.FindGameObjectsWithTag("Enemy");
            currentTarget = null;

            foreach (GameObject enemy in enemiesInScene)
            {
                if (enemy == this.gameObject) continue;

                float distanceToEnemy = Vector3.Distance(transform.position, enemy.transform.position);
                if (distanceToEnemy <= searchRadius && enemy.GetComponent<EnemyAI>() != null && !enemy.GetComponent<EnemyAI>().isDead)
                {
                    currentTarget = enemy;
                    break;
                }
            }
        }

        private bool IsPlayerNear()
        {
            if (player == null) return false;
            float distanceToPlayer = Vector3.Distance(transform.position, player.position);
            return distanceToPlayer <= attackRange;
        }
    }
}
