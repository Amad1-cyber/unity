using UnityEngine;
using System.Collections.Generic;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class CombineFoliageMeshes : MonoBehaviour
{
    void Start()
    {
        CombineMeshes();
    }

    void CombineMeshes()
    {
        MeshFilter[] meshFilters = GetComponentsInChildren<MeshFilter>();
        List<CombineInstance> combine = new List<CombineInstance>();

        for (int i = 0; i < meshFilters.Length; i++)
        {
            if (meshFilters[i].gameObject == this.gameObject) continue; // Skip parent object

            CombineInstance ci = new CombineInstance();
            ci.mesh = meshFilters[i].sharedMesh;
            ci.transform = meshFilters[i].transform.localToWorldMatrix;
            combine.Add(ci);

            meshFilters[i].gameObject.SetActive(false);
        }

        Mesh combinedMesh = new Mesh();
        combinedMesh.CombineMeshes(combine.ToArray(), true, true);

        MeshFilter meshFilter = GetComponent<MeshFilter>();
        meshFilter.sharedMesh = combinedMesh;

        MeshRenderer meshRenderer = GetComponent<MeshRenderer>();
        meshRenderer.enabled = true;

        gameObject.AddComponent<MeshCollider>().sharedMesh = combinedMesh;

        // Enable GPU Instancing for efficient foliage rendering
        Material[] materials = meshRenderer.sharedMaterials;
        foreach (Material mat in materials)
        {
            if (mat != null && mat.enableInstancing == false)
                mat.enableInstancing = true;
        }
    }
}
