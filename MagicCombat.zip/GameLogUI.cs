using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameLogUI : MonoBehaviour
{
    public static GameLogUI Instance;

    [Header("UI Reference")]
    [Tooltip("Text component that displays the log messages.")]
    public Text logText;

    [Header("Log Settings")]
    [Tooltip("Maximum number of messages to display in the log.")]
    public int maxMessages = 50;

    // List of allowed phrases to show in the log.
    private List<string> allowedKeywords = new List<string>
    {
        "Peace Mode is now OFF",
        "Plant is in range. Press E to pick up",
        "Plant collected:",
        "Light sphere: Press F to receive blessing",
        "Blessing received!",
        "Your land has been blessed!",
        "Defense increased by",
        "Your defense has increased"
    };

    // Internal queue to store log messages.
    private Queue<string> logQueue = new Queue<string>();

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);

        Application.logMessageReceived += HandleLog;
    }

    void OnDestroy()
    {
        Application.logMessageReceived -= HandleLog;
    }

    /// <summary>
    /// Callback invoked whenever a log message is received.
    /// Only adds messages that contain one of the allowed keywords.
    /// </summary>
    void HandleLog(string logString, string stackTrace, LogType type)
    {
        // Ignore warnings, errors, and exceptions.
        if (type == LogType.Warning || type == LogType.Error || type == LogType.Exception)
            return;

        // Check if the message contains any allowed keyword.
        bool isAllowed = false;
        foreach (string keyword in allowedKeywords)
        {
            if (logString.Contains(keyword))
            {
                isAllowed = true;
                break;
            }
        }

        if (isAllowed)
        {
            // Optionally, format the message with its log type (or just the message).
            string formattedMessage = logString;
            AddMessage(formattedMessage);
        }
    }

    /// <summary>
    /// Enqueues a new message and updates the UI.
    /// </summary>
    public void AddMessage(string message)
    {
        logQueue.Enqueue(message);
        while (logQueue.Count > maxMessages)
        {
            logQueue.Dequeue();
        }
        UpdateLogUI();
    }

    /// <summary>
    /// Updates the UI Text with the current log messages.
    /// </summary>
    void UpdateLogUI()
    {
        if (logText != null)
            logText.text = string.Join("\n", logQueue.ToArray());
    }
}
