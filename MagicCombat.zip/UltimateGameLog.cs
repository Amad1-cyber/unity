using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class UltimateGameLog : MonoBehaviour
{
    public static UltimateGameLog Instance;

    [Header("UI References")]
    [Tooltip("UI Text component that displays the entire log.")]
    public Text logText;  // If using TextMeshPro, use TMP_Text instead.

    [Header("Log Settings")]
    [Tooltip("Maximum number of log lines to keep in the console.")]
    public int maxLines = 200;

    [Tooltip("Include stack traces for errors and exceptions?")]
    public bool includeStackTraceForErrors = true;

    // Internal list to store all log lines.
    private readonly List<string> logLines = new List<string>();

    void Awake()
    {
        // Set up singleton instance.
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        // Subscribe to Unity's log event to capture all debug messages.
        Application.logMessageReceived += HandleUnityLog;
    }

    void OnDestroy()
    {
        Application.logMessageReceived -= HandleUnityLog;
    }

    /// <summary>
    /// Unity's log callback. Captures every Debug.Log, LogWarning, LogError, etc.
    /// Also adds optional stack traces for errors/exceptions.
    /// </summary>
    void HandleUnityLog(string logString, string stackTrace, LogType type)
    {
        // Timestamp for the message, e.g. [17:42:13]
        string timeStamp = DateTime.Now.ToString("HH:mm:ss");

        // Format: [17:42:13] [LogType] message
        string formattedMessage = $"[{timeStamp}] [{type}] {logString}";

        // For errors/exceptions, optionally append stack trace.
        if ((type == LogType.Error || type == LogType.Exception || type == LogType.Assert)
            && includeStackTraceForErrors
            && !string.IsNullOrEmpty(stackTrace))
        {
            formattedMessage += $"\n{stackTrace}";
        }

        AddLine(formattedMessage);
    }

    /// <summary>
    /// Call this method to manually add a line of text to the log
    /// for custom "player activity" or "UI activity" messages that
    /// may not come from Debug.Log.
    /// </summary>
    public void AddManualLog(string message)
    {
        // You could also add timestamps or formatting here if desired.
        // E.g. "PlayerActivity: " or "UIActivity: "
        // For simplicity, we just pass the raw message.
        AddLine(message);
    }

    /// <summary>
    /// Enqueues a new line in our log list and updates the UI.
    /// </summary>
    void AddLine(string line)
    {
        logLines.Add(line);
        while (logLines.Count > maxLines)
        {
            logLines.RemoveAt(0);
        }
        UpdateLogUI();
    }

    /// <summary>
    /// Updates the UI Text element with all stored log lines.
    /// </summary>
    void UpdateLogUI()
    {
        if (logText != null)
        {
            logText.text = string.Join("\n", logLines);
        }
    }
}
