using UnityEngine;
using FPSRetroKit;

public class LightSphereBlessing : MonoBehaviour
{
    [Header("Blessing Settings")]
    [Tooltip("The number of plants required to trigger the blessing.")]
    public int requiredPlants = 10;
    [Tooltip("Amount to increase the player's defense.")]
    public int defenseIncreaseAmount = 5;
    [Tooltip("Key to trigger the blessing interaction.")]
    public KeyCode interactKey = KeyCode.F;

    [Header("Dialogue / Effects")]
    public AudioClip blessingSound; // Optional sound when blessing occurs.

    private AudioSource audioSource;
    private bool playerInRange = false;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
            audioSource = gameObject.AddComponent<AudioSource>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
            Debug.Log("Light sphere: Press F to receive blessing.");
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
        }
    }

    void Update()
    {
        if (playerInRange && Input.GetKeyDown(interactKey))
        {
            AttemptBlessing();
        }
    }

    void AttemptBlessing()
    {
        if (PlantCollector.Instance != null && PlantCollector.Instance.HasEnoughPlants(requiredPlants))
        {
            // Increase player's defense via PlayerDataManager.
            if (PlayerDataManager.Instance != null)
            {
                PlayerDataManager.Instance.defense += defenseIncreaseAmount;
                Debug.Log($"Blessing received! Defense increased by {defenseIncreaseAmount}. New defense: {PlayerDataManager.Instance.defense}");
            }
            else
            {
                Debug.LogWarning("PlayerDataManager not found!");
            }

            // Optionally play blessing sound.
            if (blessingSound != null && audioSource != null)
                audioSource.PlayOneShot(blessingSound);

            // Reset collected plants.
            PlantCollector.Instance.ResetPlants();

            // Optionally display dialogue.
            // (Replace with your dialogue system; here we use Debug.Log.)
            Debug.Log("Light Sphere: Your land has been blessed! Your defense has increased.");
        }
        else
        {
            Debug.Log("Not enough plants collected for blessing.");
        }
    }
}
