﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FPSRetroKit
{
	public class SkullMonster : Enemy
	{

	}
}
