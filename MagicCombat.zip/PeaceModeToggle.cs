using UnityEngine;

namespace FPSRetroKit
{
    public class PeaceModeToggle : MonoBehaviour
    {
        [Header("Toggle Settings")]
        [Tooltip("Key to toggle Peace Mode (default: 4)")]
        public KeyCode toggleKey = KeyCode.Alpha4;

        [Tooltip("If true, Peace Mode is active.")]
        public bool isPeaceMode = false;

        [Header("UI References")]
        [Tooltip("GameObject for combat UI (e.g. first-person hand/weapon).")]
        public GameObject combatUI;

        [Tooltip("GameObject for Peace Mode UI (e.g. holy water panel).")]
        public GameObject peaceUI;

        // Optional: you can add more functionality here (such as playing a sound)

        void Start()
        {
            // Set initial state on start.
            SetPeaceMode(isPeaceMode);
        }

        void Update()
        {
            // Toggle peace mode by pressing the designated key (default 4)
            if (Input.GetKeyDown(toggleKey))
            {
                isPeaceMode = !isPeaceMode;
                SetPeaceMode(isPeaceMode);
            }

            // Also toggle peace mode when scrolling the mouse wheel (scroll up as an example)
            float scroll = Input.GetAxis("Mouse ScrollWheel");
            if (scroll > 0.1f)
            {
                isPeaceMode = !isPeaceMode;
                SetPeaceMode(isPeaceMode);
            }
        }

        void SetPeaceMode(bool mode)
        {
            // If combat UI is assigned, disable it in peace mode.
            if (combatUI != null)
                combatUI.SetActive(!mode);

            // If peace UI is assigned, enable it in peace mode.
            if (peaceUI != null)
                peaceUI.SetActive(mode);

            Debug.Log("Peace Mode is now " + (mode ? "ON" : "OFF"));
        }
    }
}
