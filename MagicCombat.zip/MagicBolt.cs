using UnityEngine;

namespace FPSRetroKit
{
    public class MagicBolt : MonoBehaviour
    {
        public int damage = 25; // Damage of the bolt
        public float lifeTime = 5f; // Time before the bolt disappears
        public float speed = 10f; // Speed of the magic bolt

        void Start()
        {
            Destroy(gameObject, lifeTime); // Destroy after a certain time
        }

        void Update()
        {
            // Move the bolt forward
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Enemy"))
            {
                Enemy enemy = other.GetComponent<Enemy>();
                if (enemy != null)
                {
                    enemy.TakeDamage(damage);
                    UnityEngine.Debug.Log($"Magic Bolt hit enemy for {damage} damage.");
                }
                Destroy(gameObject);
            }
        }
    }
}
