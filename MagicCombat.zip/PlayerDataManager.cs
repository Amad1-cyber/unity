using UnityEngine;

namespace FPSRetroKit
{
    public class PlayerDataManager : MonoBehaviour
    {
        public static PlayerDataManager Instance { get; private set; }

        [Header("Level and Experience")]
        public int level = 1;
        public float currentExperience = 0f;
        public float experienceToNextLevel = 100f;

        [Header("Health Settings")]
        public int maxHealth = 100;
        public int currentHealth = 100;

        [Header("Mana Settings")]
        public float maxMana = 100f;
        public float currentMana = 100f;
        public float manaRegenRate = 5f;

        [Header("Attributes")]
        public int intel = 10;
        public int smarts = 10;    // Formerly wisdom
        public int healthy = 10;   // Formerly constitution
        public int defense = 5;

        [Header("Equipment Flags")]
        public bool hasHolyShirt = false;  // Set true when the holy shirt is picked up

        void Awake()
        {
            // Singleton pattern � if an instance already exists, destroy this one.
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            Debug.Log($"[PlayerDataManager] Initialized: Level {level}, HP {currentHealth}/{maxHealth}, Mana {currentMana}/{maxMana}");
        }

        public void LevelUp()
        {
            level++;
            maxHealth += 10;
            currentHealth = maxHealth;
            maxMana += 5;
            currentMana = maxMana;
            intel++;
            smarts++;
            healthy++;
            defense += 2;
            currentExperience = 0f;
            experienceToNextLevel *= 1.5f;
            Debug.Log($"[PlayerDataManager] Level Up! Now Level {level} | HP: {currentHealth}/{maxHealth}, Mana: {currentMana}/{maxMana} | Intel: {intel}, Smarts: {smarts}, Healthy: {healthy}, Defense: {defense}");
        }

        public void AddExperience(float xp)
        {
            currentExperience += xp;
            if (currentExperience >= experienceToNextLevel)
                LevelUp();
        }

        public void TakeDamage(int damage)
        {
            int effectiveDamage = Mathf.Max(damage - defense, 1);
            currentHealth -= effectiveDamage;
            currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
            Debug.Log($"[PlayerDataManager] Took {effectiveDamage} damage. HP: {currentHealth}/{maxHealth}");
        }

        public void RestoreHealth(int amount)
        {
            currentHealth += amount;
            currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
            Debug.Log($"[PlayerDataManager] Restored health. HP: {currentHealth}/{maxHealth}");
        }

        public void RestoreMana(float amount)
        {
            currentMana += amount;
            currentMana = Mathf.Clamp(currentMana, 0f, maxMana);
            Debug.Log($"[PlayerDataManager] Restored mana. Mana: {currentMana}/{maxMana}");
        }
    }
}
