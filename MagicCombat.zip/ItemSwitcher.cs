using System.Collections.Generic;
using UnityEngine;

namespace FPSRetroKit
{
    public class ItemSwitcher : MonoBehaviour
    {
        [Header("Item List Settings")]
        [Tooltip("List of item GameObjects (e.g., holy water bottle, potion, etc.)")]
        public List<Transform> items = new List<Transform>();

        [Tooltip("Automatically fill items list with all children of this GameObject.")]
        public bool autoFill = true;

        [Tooltip("Index of the item to start with (default is 0).")]
        public int initialItem = 0;

        private int selectedItem = 0;

        void Awake()
        {
            if (autoFill)
            {
                // Clear any pre-assigned items and add all children.
                items.Clear();
                foreach (Transform child in transform)
                {
                    items.Add(child);
                }
            }
        }

        void Start()
        {
            if (items == null || items.Count == 0)
            {
                Debug.LogWarning("No items found in ItemSwitcher.");
                return;
            }
            selectedItem = initialItem % items.Count;
            UpdateItems();
        }

        void Update()
        {
            // Switch items using mouse scroll.
            float scroll = Input.GetAxis("Mouse ScrollWheel");
            if (scroll > 0f)
            {
                selectedItem = (selectedItem + 1) % items.Count;
                UpdateItems();
            }
            else if (scroll < 0f)
            {
                selectedItem = (selectedItem - 1 + items.Count) % items.Count;
                UpdateItems();
            }

            // Also allow numeric keys for switching (1 = first item, 2 = second, etc.)
            if (Input.GetKeyDown(KeyCode.Alpha1))
            {
                selectedItem = 0;
                UpdateItems();
            }
            else if (Input.GetKeyDown(KeyCode.Alpha2) && items.Count > 1)
            {
                selectedItem = 1;
                UpdateItems();
            }
            else if (Input.GetKeyDown(KeyCode.Alpha3) && items.Count > 2)
            {
                selectedItem = 2;
                UpdateItems();
            }
            // You can add more keys if you have more than 3 items.
        }

        void UpdateItems()
        {
            // Loop through the list and enable the selected item while disabling the others.
            for (int i = 0; i < items.Count; i++)
            {
                if (i == selectedItem)
                {
                    items[i].gameObject.SetActive(true);
                }
                else
                {
                    items[i].gameObject.SetActive(false);
                }
            }
            Debug.Log("Selected item: " + items[selectedItem].name);
        }
    }
}
