using UnityEngine;
using FPSRetroKit; // Ensure this matches your namespace

public class HolyShirtPickup : MonoBehaviour
{
    public Sprite holyShirtSprite;  // The holy shirt sprite (e.g., representing yellow-handed appearance)
    public SpriteRenderer playerClothingRenderer; // Optional, for immediate appearance update
    public AudioClip pickupSound;

    private AudioSource audioSource;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
            audioSource = gameObject.AddComponent<AudioSource>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            // Set the holy shirt flag in PlayerDataManager.
            if (PlayerDataManager.Instance != null)
            {
                PlayerDataManager.Instance.hasHolyShirt = true;
                Debug.Log("[HolyShirtPickup] Holy shirt picked up. hasHolyShirt set to true.");
            }

            // Optionally change the player's clothing sprite.
            if (playerClothingRenderer == null)
                playerClothingRenderer = other.GetComponentInChildren<SpriteRenderer>();
            if (playerClothingRenderer != null && holyShirtSprite != null)
                playerClothingRenderer.sprite = holyShirtSprite;

            // Force the combat manager to refresh the idle sprite.
            CombatPeaceManager modeManager = other.GetComponentInChildren<CombatPeaceManager>();
            if (modeManager == null)
                modeManager = Object.FindAnyObjectByType<CombatPeaceManager>();
            if (modeManager != null)
                modeManager.RefreshSpritesImmediately();

            // Play pickup sound.
            if (pickupSound != null && audioSource != null)
                audioSource.PlayOneShot(pickupSound);

            Destroy(gameObject);
        }
    }
}
