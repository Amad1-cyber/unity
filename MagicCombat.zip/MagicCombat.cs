using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public class MagicCombat : MonoBehaviour
    {
        [Header("Magic Projectile Settings")]
        public GameObject magicProjectilePrefab;
        public Transform magicSpawnPoint;
        public float magicProjectileSpeed = 20f;
        public float magicDamage = 25f;
        public float magicManaCost = 20f;

        [Header("Mana Settings")]
        public float maxMana = 100f;
        public float manaRegenRate = 5f;
        public float currentMana;

        [Header("UI Elements")]
        public Text manaText;  // Optional UI text for mana display

        [Header("Audio Settings")]
        public AudioClip magicCastingSound;
        private AudioSource audioSource;

        void Start()
        {
            currentMana = maxMana;
            UpdateManaUI();

            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
                audioSource = gameObject.AddComponent<AudioSource>();
        }

        void Update()
        {
            // Regenerate mana
            if (currentMana < maxMana)
            {
                currentMana += manaRegenRate * Time.deltaTime;
                currentMana = Mathf.Clamp(currentMana, 0f, maxMana);
            }
            UpdateManaUI();

            // Casting if user presses Fire1 (left click, by default)
            if (Input.GetButtonDown("Fire1"))
            {
                if (currentMana >= magicManaCost)
                {
                    if (magicCastingSound != null)
                        audioSource.PlayOneShot(magicCastingSound);

                    CastMagicProjectile();
                    currentMana -= magicManaCost;
                    UpdateManaUI();
                }
                else
                {
                    Debug.Log("Not enough mana to cast magic! Current mana: " + currentMana);
                }
            }
        }

        /// <summary>
        /// Public method that external scripts can call to add mana.
        /// (Used by holy cigarette, etc.)
        /// </summary>
        public void AddMana(float amount)
        {
            currentMana += amount;
            currentMana = Mathf.Clamp(currentMana, 0f, maxMana);
            Debug.Log($"[MagicCombat] +{amount} Mana. Now: {currentMana}/{maxMana}");
            UpdateManaUI();
        }

        private void UpdateManaUI()
        {
            if (manaText != null)
            {
                manaText.text = $"Mana: {Mathf.RoundToInt(currentMana)}/{Mathf.RoundToInt(maxMana)}";
            }
        }

        private void CastMagicProjectile()
        {
            Debug.Log("Casting magic attack...");
            if (magicProjectilePrefab != null && magicSpawnPoint != null)
            {
                GameObject projectile = Instantiate(magicProjectilePrefab, magicSpawnPoint.position, magicSpawnPoint.rotation);
                Rigidbody rb = projectile.GetComponent<Rigidbody>();
                if (rb != null)
                {
                    // Use velocity or linearVelocity, depending on your Unity version
                    rb.linearVelocity = magicSpawnPoint.forward * magicProjectileSpeed;
                }

                // If you have a script like FireballBehavior to set damage, do so here
                FireballBehavior fb = projectile.GetComponent<FireballBehavior>();
                if (fb != null)
                {
                    fb.damage = Mathf.RoundToInt(magicDamage);
                }
            }
            else
            {
                Debug.LogWarning("Magic projectile or spawn point not assigned!");
            }
        }
    }
}
