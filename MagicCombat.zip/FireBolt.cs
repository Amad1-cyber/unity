using UnityEngine;

namespace FPSRetroKit
{
    public class FireBolt : MonoBehaviour
    {
        public int damage = 25; // Fire Bolt damage
        public float lifeTime = 5f;

        void Start()
        {
            Destroy(gameObject, lifeTime); // Destroy the fire bolt after a few seconds
        }

        private void OnTriggerEnter(Collider other)
        {
            // Check if the fire bolt hits an enemy
            EnemyAI enemy = other.GetComponent<EnemyAI>();
            if (enemy != null)
            {
                enemy.TakeDamage(damage);
                UnityEngine.Debug.Log("Fire Bolt hit enemy!");
            }

            Destroy(gameObject); // Destroy fire bolt on impact
        }
    }
}
