﻿using UnityEngine;

namespace FPSRetroKit
{
    public class MagicAttack : MonoBehaviour
    {
        public GameObject fireballPrefab;
        public Transform fireballSpawnPoint;
        public float fireballSpeed = 20f;
        public float fireballDamage = 25f;  // Damage defined as float

        void Update()
        {
            // Example input: press left-click to fire
            if (Input.GetMouseButtonDown(0))
            {
                CastFireBolt();
            }
        }

        public void CastFireBolt()
        {
            Debug.Log("🔥 Fire Bolt cast!");

            if (fireballPrefab != null && fireballSpawnPoint != null)
            {
                // Create the fireball at the spawn point
                GameObject fireball = Instantiate(fireballPrefab, fireballSpawnPoint.position, fireballSpawnPoint.rotation);

                // Give the fireball velocity in the forward direction
                Rigidbody rb = fireball.GetComponent<Rigidbody>();
                if (rb != null)
                {
                    rb.linearVelocity = fireballSpawnPoint.forward * fireballSpeed;
                }

                // Set damage on the FireballBehavior, converting the float damage to an int.
                FireballBehavior fb = fireball.GetComponent<FireballBehavior>();
                if (fb != null)
                {
                    fb.damage = Mathf.RoundToInt(fireballDamage);
                }
            }
            else
            {
                Debug.LogWarning("⚠ Fireball prefab or spawn point not assigned!");
            }
        }
    }
}
