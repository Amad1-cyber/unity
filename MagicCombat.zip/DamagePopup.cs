using UnityEngine;
using UnityEngine.UI;

public class DamagePopup : MonoBehaviour
{
    [Header("Popup Components")]
    public Text damageText;         // The UI Text that displays the damage amount.
    public CanvasGroup canvasGroup; // (Optional) CanvasGroup if needed for grouping.

    [Header("HUD Label (Optional)")]
    public Text damageHUDText;       // A reference to a HUD text element (for example, "VD: X").

    [Header("Sound Settings")]
    public AudioClip popupSound;     // Sound to play when the popup appears.
    private AudioSource audioSource;

    void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
            audioSource = gameObject.AddComponent<AudioSource>();
    }

    void Start()
    {
        if (popupSound != null)
            audioSource.PlayOneShot(popupSound);
    }

    // No Update method for fading or destruction.
    // The popup will remain at full opacity until removed by other scripts or manually.

    /// <summary>
    /// Updates the damage popup text (and optionally the HUD label) with the given damage value.
    /// Call this method each time the damage value changes.
    /// </summary>
    public void SetDamage(int damage)
    {
        if (damageText != null)
            damageText.text = "-" + damage.ToString();

        if (damageHUDText != null)
            damageHUDText.text = "VD: " + damage;
    }
}
