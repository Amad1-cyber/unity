using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public class PlayerAttributesUI : MonoBehaviour
    {
        public Text healthText;
        public Text manaText;
        public Text xpText;
        public Text levelText;
        public Text intelText;
        public Text smartsText;
        public Text healthyText;
        public Text defenseText;

        void Update()
        {
            if (PlayerDataManager.Instance == null)
                return;

            // Update each text field with the corresponding property.
            if (healthText != null)
                healthText.text = $"HP: {PlayerDataManager.Instance.currentHealth}/{PlayerDataManager.Instance.maxHealth}";
            if (manaText != null)
                manaText.text = $"Mana: {PlayerDataManager.Instance.currentMana}/{PlayerDataManager.Instance.maxMana}";
            if (xpText != null)
                xpText.text = $"XP: {PlayerDataManager.Instance.currentExperience}/{PlayerDataManager.Instance.experienceToNextLevel}";
            if (levelText != null)
                levelText.text = $"Level: {PlayerDataManager.Instance.level}";
            if (intelText != null)
                intelText.text = $"Intel: {PlayerDataManager.Instance.intel}";
            if (smartsText != null)
                smartsText.text = $"Smarts: {PlayerDataManager.Instance.smarts}";
            if (healthyText != null)
                healthyText.text = $"Healthy: {PlayerDataManager.Instance.healthy}";
            if (defenseText != null)
                defenseText.text = $"Defense: {PlayerDataManager.Instance.defense}";
        }
    }
}
