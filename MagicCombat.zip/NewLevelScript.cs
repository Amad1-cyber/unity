using UnityEngine;

namespace FPSRetroKit
{
    public class NewLevelScript : MonoBehaviour
    {
        public Enemy enemy;

        void Update()
        {
            if (enemy != null && enemy.Health <= 0)
            {
                UnityEngine.Debug.Log("Enemy defeated! Proceed to next level.");
                // Trigger level change logic here
            }
        }
    }
}
