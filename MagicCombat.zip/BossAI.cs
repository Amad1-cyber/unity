using UnityEngine;
using UnityEngine.AI;
using System.Collections;
using FPSRetroKit; // Adjust the namespace if needed

namespace FPSRetroKit
{
    public class BossAI : MonoBehaviour
    {
        [Header("Boss Stats")]
        public int maxHealth = 500;
        private int currentHealth;

        [Header("Experience Reward")]
        public float xpReward = 20000f; // Major XP reward on boss defeat
        private bool hasGivenXP = false;

        [Header("Combat Settings")]
        public float chaseRange = 30f;
        public float assaultRange = 5f;
        public float attackCooldown = 2f;
        private float lastAttackTime;
        public int assaultDamage = 30;

        [Header("Movement Settings")]
        public float speed = 4.5f;
        public Transform playerTarget;
        private NavMeshAgent agent;

        [Header("Death & Chalice Settings")]
        public GameObject chalicePrefab;    // Portal prefab to appear after boss defeat
        public Transform chaliceSpawnPoint;   // Spawn location for the chalice portal
        public GameObject deathEffect;
        public AudioClip deathSound;
        private AudioSource audioSource;

        [Header("Animation Settings")]
        public Animator animator;
        // Expected animator triggers/bools: "isRunning", "Attack", "TakeDamage", "Die"

        void Start()
        {
            currentHealth = maxHealth;
            agent = GetComponent<NavMeshAgent>();
            audioSource = GetComponent<AudioSource>();

            if (agent != null)
                agent.speed = speed;

            // If playerTarget is not assigned, try to find it by tag "Player"
            if (playerTarget == null)
            {
                GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
                if (playerObj != null)
                    playerTarget = playerObj.transform;
            }
        }

        void Update()
        {
            if (playerTarget == null)
                return;

            float distanceToPlayer = Vector3.Distance(transform.position, playerTarget.position);

            if (distanceToPlayer <= assaultRange)
            {
                AssaultPlayer();
            }
            else if (distanceToPlayer <= chaseRange)
            {
                ChasePlayer();
            }
            else
            {
                Idle();
            }
        }

        void ChasePlayer()
        {
            if (animator != null)
                animator.SetBool("isRunning", true);

            if (agent != null)
                agent.SetDestination(playerTarget.position);

            FacePlayer();
        }

        void Idle()
        {
            if (animator != null)
                animator.SetBool("isRunning", false);

            if (agent != null)
                agent.ResetPath();
        }

        void AssaultPlayer()
        {
            if (Time.time - lastAttackTime >= attackCooldown)
            {
                lastAttackTime = Time.time;
                FacePlayer();

                if (animator != null)
                    animator.SetTrigger("Attack");

                // Damage the player
                PlayerHealth pHealth = playerTarget.GetComponent<PlayerHealth>();
                if (pHealth != null)
                {
                    pHealth.TakeDamage(assaultDamage);
                }
            }
        }

        void FacePlayer()
        {
            if (playerTarget == null)
                return;

            Vector3 direction = (playerTarget.position - transform.position).normalized;
            direction.y = 0;
            transform.rotation = Quaternion.LookRotation(direction);
        }

        // This method is called by the projectile or other damage source.
        public void TakeDamage(int damage)
        {
            currentHealth -= damage;

            if (animator != null)
                animator.SetTrigger("TakeDamage");

            Debug.Log($"[BossAI] Took {damage} damage. Current Health: {currentHealth}/{maxHealth}");

            if (currentHealth <= 0)
            {
                if (!hasGivenXP)
                {
                    hasGivenXP = true;
                    GivePlayerXP();
                }
                StartCoroutine(Die());
            }
        }

        private IEnumerator Die()
        {
            if (animator != null)
                animator.SetTrigger("Die");

            if (agent != null)
                agent.isStopped = true;

            if (deathEffect != null)
                Instantiate(deathEffect, transform.position, Quaternion.identity);

            if (deathSound != null && audioSource != null)
                audioSource.PlayOneShot(deathSound);

            // Wait for death animation/effects
            yield return new WaitForSeconds(2f);

            ActivateChalice();
            Destroy(gameObject);
        }

        private void GivePlayerXP()
        {
            if (playerTarget == null)
                return;

            PlayerHealth pHealth = playerTarget.GetComponent<PlayerHealth>();
            if (pHealth != null)
            {
                Debug.Log($"[BossAI] Boss defeated! Granting {xpReward} XP to the player.");
                pHealth.AddExperience(xpReward);
            }
        }

        private void ActivateChalice()
        {
            if (chalicePrefab != null && chaliceSpawnPoint != null)
            {
                Instantiate(chalicePrefab, chaliceSpawnPoint.position, chaliceSpawnPoint.rotation);
                Debug.Log("[BossAI] Chalice portal has been activated!");
            }
            else
            {
                Debug.LogWarning("[BossAI] ChalicePrefab or ChaliceSpawnPoint not assigned!");
            }
        }
    }
}
