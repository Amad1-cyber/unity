using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DamageLogUI : MonoBehaviour
{
    // Singleton instance (optional, if you wish to access it from other scripts)
    public static DamageLogUI Instance;

    [Header("UI Reference")]
    [Tooltip("Text component that will display the damage log messages.")]
    public Text damageLogText;

    [Header("Log Settings")]
    [Tooltip("Maximum number of messages to display.")]
    public int maxMessages = 10;

    // Internal queue to hold messages.
    private Queue<string> logQueue = new Queue<string>();

    void Awake()
    {
        // Set up singleton.
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);

        // Subscribe to Unity's log message event.
        Application.logMessageReceived += HandleLog;
    }

    void OnDestroy()
    {
        // Unsubscribe when the object is destroyed.
        Application.logMessageReceived -= HandleLog;
    }

    /// <summary>
    /// Callback method for handling debug logs.
    /// Only messages containing certain keywords (e.g., "Damage" or "HP:") are added.
    /// </summary>
    /// <param name="logString">The log message.</param>
    /// <param name="stackTrace">The stack trace.</param>
    /// <param name="type">The log type (Log, Warning, Error, etc.).</param>
    void HandleLog(string logString, string stackTrace, LogType type)
    {
        // Filter: only add messages related to damage events.
        if (logString.Contains("Damage") || logString.Contains("HP:"))
        {
            AddMessage(logString);
        }
    }

    /// <summary>
    /// Adds a new message to the log and updates the UI.
    /// </summary>
    /// <param name="message">The message to add.</param>
    public void AddMessage(string message)
    {
        logQueue.Enqueue(message);
        if (logQueue.Count > maxMessages)
            logQueue.Dequeue();
        UpdateUI();
    }

    /// <summary>
    /// Updates the UI text with the current log queue.
    /// </summary>
    private void UpdateUI()
    {
        if (damageLogText != null)
            damageLogText.text = string.Join("\n", logQueue.ToArray());
    }
}
