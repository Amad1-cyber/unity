﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public class MagicMeleeAttack : MonoBehaviour
    {
        [Header("Mode Settings")]
        public bool isMagicMode = true;  // Start in Magic Mode by default
        public Text modeText;            // Optional UI text to display "Magic Mode" / "Melee Mode"

        [Header("Magic Settings")]
        public GameObject fireballPrefab;
        public Transform fireballSpawnPoint;
        public float fireballSpeed = 20f;
        public float fireballDamage = 25f;

        [Header("Melee Settings")]
        public int meleeDamage = 40;
        public float meleeRange = 3f;
        public Sprite[] meleePunchSprites;   // Fist frames (pixel-art) for left punch, right punch, etc.
        public Image meleeImage;             // UI Image on the Canvas for punch animation
        public float meleeAnimationFrameRate = 0.1f;

        [Header("References")]
        public Camera playerCamera;          // Main camera (drag your Player Camera or use Camera.main)

        void Start()
        {
            // If no camera assigned, use main
            if (playerCamera == null)
                playerCamera = Camera.main;

            // Hide the melee UI at start
            if (meleeImage != null)
                meleeImage.gameObject.SetActive(false);

            UpdateModeUI();
        }

        void Update()
        {
            // Scroll wheel toggles mode
            float scroll = Input.GetAxis("Mouse ScrollWheel");
            if (scroll != 0)
            {
                isMagicMode = !isMagicMode;
                Debug.Log("Switched to " + (isMagicMode ? "Magic" : "Melee") + " Mode");
                UpdateModeUI();
            }

            // Fire1 (left click) => either shoot fireball or do melee
            if (Input.GetButtonDown("Fire1"))
            {
                if (isMagicMode)
                    CastFireball();
                else
                    StartCoroutine(PerformMeleeAttack());
            }
        }

        private void UpdateModeUI()
        {
            if (modeText != null)
                modeText.text = isMagicMode ? "Magic Mode" : "Melee Mode";
        }

        private void CastFireball()
        {
            Debug.Log("Casting Fireball...");
            if (fireballPrefab != null && fireballSpawnPoint != null)
            {
                // Instantiate the fireball
                GameObject fb = Instantiate(fireballPrefab, fireballSpawnPoint.position, fireballSpawnPoint.rotation);

                // Add velocity to the fireball
                Rigidbody rb = fb.GetComponent<Rigidbody>();
                if (rb != null)
                {
                    rb.linearVelocity = fireballSpawnPoint.forward * fireballSpeed;
                }

                // Set the fireball's damage (convert float -> int if needed)
                FireballBehavior fbScript = fb.GetComponent<FireballBehavior>();
                if (fbScript != null)
                    fbScript.damage = Mathf.RoundToInt(fireballDamage);
            }
            else
            {
                Debug.LogWarning("Fireball Prefab or SpawnPoint not assigned!");
            }
        }

        private IEnumerator PerformMeleeAttack()
        {
            Debug.Log("Performing Melee Attack...");

            // Show the melee UI for punch animation
            if (meleeImage != null)
                meleeImage.gameObject.SetActive(true);

            // Animate the punch frames
            if (meleePunchSprites != null && meleePunchSprites.Length > 0 && meleeImage != null)
            {
                for (int i = 0; i < meleePunchSprites.Length; i++)
                {
                    meleeImage.sprite = meleePunchSprites[i];
                    yield return new WaitForSeconds(meleeAnimationFrameRate);
                }
                // Hide the sprite after finishing
                meleeImage.sprite = null;
                meleeImage.gameObject.SetActive(false);
            }
            else
            {
                // If no sprites, just wait a short time
                yield return new WaitForSeconds(0.2f);
            }

            // After animation, do a raycast to see if we hit an enemy
            Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, meleeRange))
            {
                if (hit.collider.CompareTag("Enemy"))
                {
                    EnemyAI_3D enemy = hit.collider.GetComponent<EnemyAI_3D>();
                    if (enemy != null)
                    {
                        enemy.TakeDamage(meleeDamage);
                        Debug.Log("Melee hit " + enemy.gameObject.name + " for " + meleeDamage + " damage.");
                    }
                }
            }
        }
    }
}
