using UnityEngine;

namespace FPSRetroKit
{
    public class TameModeSkill : MonoBehaviour
    {
        [Header("Tame Mode Settings")]
        [Tooltip("Key or input axis for attempting to tame (default: Fire1).")]
        public string tameInput = "Fire1";

        [Tooltip("Max range for taming raycast.")]
        public float tameRange = 3f;

        [Tooltip("Reference to the camera for raycasting (if null, uses Camera.main).")]
        public Camera playerCamera;

        [Tooltip("Optional sound to play when you attempt to tame (success/fail logic is in TameableEnemy).")]
        public AudioClip tameAttemptSound;

        private AudioSource audioSource;

        void Start()
        {
            if (playerCamera == null)
            {
                playerCamera = Camera.main;
            }

            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
            {
                audioSource = gameObject.AddComponent<AudioSource>();
            }
        }

        void Update()
        {
            // If this TameModeSkill GameObject is active, we assume we are in Tame Mode.
            // Press Fire1 to attempt taming.
            if (Input.GetButtonDown(tameInput))
            {
                AttemptTame();
            }
        }

        /// <summary>
        /// Performs a raycast to attempt taming an enemy in front of the camera.
        /// </summary>
        private void AttemptTame()
        {
            // Optionally play a sound just for the attempt.
            if (tameAttemptSound != null)
            {
                audioSource.PlayOneShot(tameAttemptSound);
            }

            // Raycast from the center of the screen forward.
            Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, tameRange))
            {
                // If the hit object is a TameableEnemy, call TameEnemy().
                // We can do it via SendMessage or direct GetComponent.
                TameableEnemy tameable = hit.collider.GetComponent<TameableEnemy>();
                if (tameable != null)
                {
                    // SendMessage approach:
                    // hit.collider.gameObject.SendMessage("TameEnemy", SendMessageOptions.DontRequireReceiver);

                    // Or direct approach:
                    tameable.TameEnemy();
                }
                else
                {
                    Debug.Log("No TameableEnemy found on " + hit.collider.gameObject.name);
                }
            }
            else
            {
                Debug.Log("Tame raycast did not hit anything within range.");
            }
        }
    }
}
