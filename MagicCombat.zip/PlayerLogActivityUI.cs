using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerActivityLogUI : MonoBehaviour
{
    public static PlayerActivityLogUI Instance;

    [Header("UI Reference")]
    [Tooltip("UI Text component that displays player activity messages.")]
    public Text logText;

    [Header("Log Settings")]
    [Tooltip("Maximum number of messages to display.")]
    public int maxMessages = 50;

    // List of allowed keywords (case-insensitive) that will be logged.
    // You can add any additional enemy type keywords here.
    private List<string> allowedKeywords = new List<string>
    {
        "Peace Mode is now",
        "Plant is in range. Press E",
        "Plant collected:",
        "Casting magic attack",
        "Fire Bolt cast",
        "Melee hit",
        "Damage dealt",
        "slime",
        "devil",
        "other defeated", // generic enemy defeat message
        "enemy defeated"
    };

    // Internal queue to store log messages.
    private Queue<string> logQueue = new Queue<string>();

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);

        Application.logMessageReceived += HandleLog;
    }

    void OnDestroy()
    {
        Application.logMessageReceived -= HandleLog;
    }

    /// <summary>
    /// Callback invoked whenever a log message is received.
    /// Only messages containing one of the allowed keywords are enqueued.
    /// </summary>
    void HandleLog(string logString, string stackTrace, LogType type)
    {
        // Only process regular log messages (ignore warnings/errors).
        if (type != LogType.Log)
            return;

        // Check if the log contains any of the allowed keywords.
        foreach (string keyword in allowedKeywords)
        {
            if (logString.ToLower().Contains(keyword.ToLower()))
            {
                AddMessage(logString);
                break;
            }
        }
    }

    /// <summary>
    /// Enqueues a new message and updates the UI.
    /// </summary>
    public void AddMessage(string message)
    {
        logQueue.Enqueue(message);
        while (logQueue.Count > maxMessages)
        {
            logQueue.Dequeue();
        }
        UpdateLogUI();
    }

    /// <summary>
    /// Updates the UI Text component with the current log messages.
    /// </summary>
    void UpdateLogUI()
    {
        if (logText != null)
        {
            logText.text = string.Join("\n", logQueue.ToArray());
        }
    }
}
