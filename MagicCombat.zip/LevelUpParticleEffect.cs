using UnityEngine;

namespace FPSRetroKit
{
    public class LevelUpParticleEffect : MonoBehaviour
    {
        private ParticleSystem _particleSystem; // Renamed to avoid conflicts

        void Start()
        {
            _particleSystem = GetComponent<ParticleSystem>();
        }

        public void PlayEffect()
        {
            if (_particleSystem != null)
            {
                _particleSystem.Play();
            }
        }
    }
}
