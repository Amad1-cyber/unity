using UnityEngine;
using UnityEngine.UI;

public class DPSPopup : MonoBehaviour
{
    [Header("Popup Components")]
    [Tooltip("UI Text that displays the damage amount.")]
    public Text damageText;

    [Header("HUD Label (Optional)")]
    [Tooltip("A reference to a persistent UI Text element (for example, in your main HUD) that shows the latest damage value (e.g. 'VD: 40').")]
    public Text damageHUDText;

    [Header("Sound Settings")]
    [Tooltip("Sound to play when this popup appears.")]
    public AudioClip popupSound;

    private AudioSource audioSource;

    // Awake: Get or add an AudioSource component.
    void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    // Start: Play the sound effect on creation.
    void Start()
    {
        if (popupSound != null)
        {
            audioSource.PlayOneShot(popupSound);
        }
    }

    /// <summary>
    /// Updates the damage popup text (and optional HUD label) with the given damage value.
    /// Call this method each time you need to update the damage value.
    /// </summary>
    /// <param name="damage">The damage value to display.</param>
    public void SetDamage(int damage)
    {
        if (damageText != null)
        {
            damageText.text = "-" + damage.ToString();
        }

        if (damageHUDText != null)
        {
            damageHUDText.text = "VD: " + damage.ToString();
        }
    }
}
