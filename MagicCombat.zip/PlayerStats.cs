using UnityEngine;
using Debug = UnityEngine.Debug; // Ensures Debug refers to UnityEngine.Debug

namespace FPSRetroKit
{
    public class PlayerStats : MonoBehaviour
    {
        public int maxHealth = 100;
        public int currentHealth;
        public int level = 1;
        public float experience = 0f;
        public float experienceToNextLevel = 100f;

        void Start()
        {
            currentHealth = maxHealth;
            UnityEngine.Debug.Log("Player initialized with full health.");
        }

        public void TakeDamage(int damage)
        {
            currentHealth -= damage;
            UnityEngine.Debug.Log($"Player took {damage} damage. Remaining health: {currentHealth}");

            if (currentHealth <= 0)
            {
                Die();
            }
        }

        public void GainExperience(float xp)
        {
            experience += xp;
            UnityEngine.Debug.Log($"Gained {xp} XP. Total XP: {experience}");

            if (experience >= experienceToNextLevel)
            {
                LevelUp();
            }
        }

        void LevelUp()
        {
            level++;
            experience = 0f;
            experienceToNextLevel *= 1.5f;
            maxHealth += 20;
            currentHealth = maxHealth;
            UnityEngine.Debug.Log($"Level Up! New level: {level}. Health increased to {maxHealth}.");
        }

        void Die()
        {
            UnityEngine.Debug.Log("Player has died. Game Over.");
            // Handle player death logic here (e.g., trigger game over UI)
        }
    }
}
