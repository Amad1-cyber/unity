using UnityEngine;
using UnityEngine.SceneManagement;

namespace FPSRetroKit
{
    public class ChalicePortal : MonoBehaviour
    {
        [Header("Scene Transition Settings")]
        [Tooltip("Name of the next scene to load. Leave empty if not loading a new scene.")]
        public string nextSceneName = "";
        public KeyCode interactionKey = KeyCode.E;  // Key to interact with the portal

        private bool playerInRange = false;

        void Update()
        {
            if (playerInRange && Input.GetKeyDown(interactionKey))
            {
                // If a next scene is defined, load it and then use SceneStartPoint to reposition the player
                if (!string.IsNullOrEmpty(nextSceneName))
                {
                    SceneManager.sceneLoaded += OnSceneLoaded;
                    SceneManager.LoadScene(nextSceneName);
                }
                else
                {
                    // Otherwise, simply reposition the player using SceneStartPoint in the current scene.
                    PlacePlayerUsingStartPoint();
                }
            }
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            // Unsubscribe from the event so this runs only once
            SceneManager.sceneLoaded -= OnSceneLoaded;
            PlacePlayerUsingStartPoint();
        }

        private void PlacePlayerUsingStartPoint()
        {
            // Find the SceneStartPoint in the scene and call its PlacePlayerHere method
            SceneStartPoint startPoint = FindObjectOfType<SceneStartPoint>();
            if (startPoint != null)
            {
                startPoint.PlacePlayerHere();
            }
            else
            {
                Debug.LogWarning("[ChalicePortal] No SceneStartPoint found in the scene!");
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                playerInRange = true;
                Debug.Log("[ChalicePortal] Press E to activate the portal.");
            }
        }

        private void OnTriggerExit(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                playerInRange = false;
            }
        }
    }
}
