using UnityEngine;
using UnityEngine.UI;

public class CompassUI : MonoBehaviour
{
    [Header("Player Reference")]
    [Tooltip("Drag your Player's transform here.")]
    public Transform player;

    [Header("Compass Setup")]
    [Tooltip("The RectTransform of the arrow or pointer that we rotate.")]
    public RectTransform compassArrow;

    void Update()
    {
        if (player == null || compassArrow == null)
            return;

        // 1) Get the player's current heading in degrees around the Y-axis.
        //    Usually player.forward's direction, but eulerAngles.y is simpler.
        float playerHeading = player.eulerAngles.y;

        // 2) Rotate the arrow so that 0 degrees is pointing 'north', 
        //    meaning if the playerHeading = 0, the arrow points up (0 in UI).
        //    If you want the arrow to turn left when the player rotates left,
        //    we do negative heading in the Z-rotation.
        compassArrow.localEulerAngles = new Vector3(0, 0, -playerHeading);
    }
}
