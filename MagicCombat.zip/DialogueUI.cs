using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public class DialogueUI : MonoBehaviour
    {
        public GameObject dialoguePanel;  // Panel that displays dialogue
        public Text dialogueText;         // Text component for dialogue
        public KeyCode advanceKey = KeyCode.Space;

        private string[] lines;
        private int currentLineIndex;
        private System.Action onCompleteCallback;
        private bool isActive = false;

        void Start()
        {
            if (dialoguePanel != null)
                dialoguePanel.SetActive(false);
        }

        public void StartDialogue(string[] dialogueLines, System.Action onComplete)
        {
            if (dialogueLines == null || dialogueLines.Length == 0)
                return;

            lines = dialogueLines;
            currentLineIndex = 0;
            onCompleteCallback = onComplete;
            isActive = true;

            if (dialoguePanel != null)
                dialoguePanel.SetActive(true);

            ShowLine();
        }

        void Update()
        {
            if (!isActive)
                return;

            if (Input.GetKeyDown(advanceKey))
            {
                AdvanceLine();
            }
        }

        private void ShowLine()
        {
            if (dialogueText != null)
                dialogueText.text = lines[currentLineIndex];
        }

        private void AdvanceLine()
        {
            currentLineIndex++;
            if (currentLineIndex >= lines.Length)
            {
                EndDialogue();
            }
            else
            {
                ShowLine();
            }
        }

        private void EndDialogue()
        {
            isActive = false;
            if (dialoguePanel != null)
                dialoguePanel.SetActive(false);

            if (onCompleteCallback != null)
                onCompleteCallback.Invoke();
        }

        public bool IsDialogueActive()
        {
            return isActive;
        }
    }
}
