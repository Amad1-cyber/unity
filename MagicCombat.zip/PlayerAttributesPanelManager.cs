using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public class PlayerAttributesPanelManager : MonoBehaviour
    {
        [Header("UI Elements")]
        public GameObject attributesPanel;
        public Text intelText;      // "Intel"
        public Text smartsText;     // "Smarts"
        public Text healthyText;    // "Healthy"
        public Text experienceText; // "Exp"

        private bool isPanelActive = false;

        void Start()
        {
            if (attributesPanel != null)
            {
                // Hide the panel on start
                attributesPanel.SetActive(false);
            }
            else
            {
                Debug.LogWarning("No panel assigned to PlayerAttributesPanelManager!", this);
            }
        }

        void Update()
        {
            // Press '1' to toggle the panel
            if (Input.GetKeyDown(KeyCode.Alpha1))
            {
                Debug.Log("Alpha1 key pressed.");
                ToggleAttributesPanel();
            }
        }

        private void ToggleAttributesPanel()
        {
            if (attributesPanel == null)
            {
                Debug.LogWarning("Can't toggle attributesPanel because it's null!", this);
                return;
            }

            isPanelActive = !isPanelActive;
            attributesPanel.SetActive(isPanelActive);

            Debug.Log($"Panel Toggled. isPanelActive = {isPanelActive}");
        }

        /// <summary>
        /// Updates the UI Text fields for intel, smarts, healthy, and experience.
        /// Call this whenever the player's attributes or experience change.
        /// </summary>
        /// <param name="newIntel">New intel (was intelligence)</param>
        /// <param name="newSmarts">New smarts (was wisdom)</param>
        /// <param name="newHealthy">New healthy (was constitution)</param>
        /// <param name="currentExperience">Current experience points</param>
        public void UpdateAttributes(int newIntel, int newSmarts, int newHealthy, float currentExperience)
        {
            // Update each text UI field if it's assigned
            if (intelText != null) intelText.text = $"Intel: {newIntel}";
            if (smartsText != null) smartsText.text = $"Smarts: {newSmarts}";
            if (healthyText != null) healthyText.text = $"Healthy: {newHealthy}";
            if (experienceText != null) experienceText.text = $"Exp: {currentExperience}";

            Debug.Log($"Attributes Updated � Intel: {newIntel}, Smarts: {newSmarts}, Healthy: {newHealthy}, Exp: {currentExperience}");
        }
    }
}
