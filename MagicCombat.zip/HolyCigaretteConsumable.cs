using System.Collections;
using UnityEngine;

namespace FPSRetroKit
{
    public class HolyCigaretteConsumable : MonoBehaviour
    {
        [Header("Cigarette Settings")]
        [Tooltip("Maximum number of holy cigarettes the player can smoke.")]
        public int maxCigarettes = 5;
        private int remainingCigarettes;

        [Header("Time Limit Settings")]
        [Tooltip("Time (in seconds) the item remains valid. (0 = no limit)")]
        public float timeLimit = 120f;
        private float timer = 0f;

        [Header("Input Settings")]
        [Tooltip("Key used to smoke the cigarette. Example: L key.")]
        public KeyCode smokeKey = KeyCode.L;

        [Header("Animation Settings")]
        [Tooltip("SpriteRenderer for the smoking animation.")]
        public SpriteRenderer spriteRenderer;

        [Tooltip("Sprites for the 'smoking' flipbook animation.")]
        public Sprite[] smokeSprites;

        [Tooltip("Seconds per animation frame in the smoking flipbook.")]
        public float frameTime = 0.1f;

        [Tooltip("Idle sprite for the cigarette when not smoking.")]
        public Sprite idleSprite;

        [Header("Mana Restoration")]
        [Tooltip("Amount of mana restored per cigarette.")]
        public float manaRestoreAmount = 50f;

        [Header("Sound Settings")]
        [Tooltip("Sound played when smoking.")]
        public AudioClip smokeSound;
        private AudioSource audioSource;

        void Start()
        {
            remainingCigarettes = maxCigarettes;
            timer = 0f;

            // Setup AudioSource
            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
                audioSource = gameObject.AddComponent<AudioSource>();

            // Set idle sprite
            if (spriteRenderer != null && idleSprite != null)
            {
                spriteRenderer.sprite = idleSprite;
            }
            else
            {
                Debug.LogWarning("HolyCigaretteConsumable: SpriteRenderer or idleSprite not assigned.");
            }
        }

        void Update()
        {
            // If we have a time limit, count down.
            if (timeLimit > 0f)
            {
                timer += Time.deltaTime;
                if (timer >= timeLimit)
                {
                    Debug.Log("Holy cigarette has expired due to time limit.");
                    Destroy(gameObject);
                    return;
                }
            }

            // Listen for the smoke key
            if (Input.GetKeyDown(smokeKey))
            {
                if (remainingCigarettes > 0)
                {
                    StartCoroutine(SmokeCigarette());
                }
                else
                {
                    Debug.Log("No holy cigarette uses remaining.");
                }
            }
        }

        private IEnumerator SmokeCigarette()
        {
            Debug.Log("Smoking holy cigarette...");

            // Play flipbook animation if assigned
            if (spriteRenderer != null && smokeSprites != null && smokeSprites.Length > 0)
            {
                for (int i = 0; i < smokeSprites.Length; i++)
                {
                    spriteRenderer.sprite = smokeSprites[i];
                    yield return new WaitForSeconds(frameTime);
                }
                // Back to idle sprite
                spriteRenderer.sprite = idleSprite;
            }
            else
            {
                // If no animation, just wait a bit
                yield return new WaitForSeconds(0.5f);
            }

            // Play smoke sound if we have one
            if (smokeSound != null)
                audioSource.PlayOneShot(smokeSound);

            // Attempt to restore mana via MagicCombat
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
            {
                MagicCombat magicCombat = player.GetComponent<MagicCombat>();
                if (magicCombat != null)
                {
                    magicCombat.AddMana(manaRestoreAmount);
                    Debug.Log($"Holy cigarette smoked: Restored {manaRestoreAmount} Mana.");
                }
                else
                {
                    Debug.LogWarning("MagicCombat script not found on Player! Cannot restore mana.");
                }
            }
            else
            {
                Debug.LogWarning("Player not found in scene! Cannot restore mana.");
            }

            // Decrement usage
            remainingCigarettes--;
            Debug.Log("Remaining holy cigarette uses: " + remainingCigarettes);

            // If no more uses, destroy item
            if (remainingCigarettes <= 0)
            {
                Debug.Log("Holy cigarette item is empty. Destroying object.");
                Destroy(gameObject);
            }
        }
    }
}
