using UnityEngine;
using System.Collections.Generic;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class MeshCombiner : MonoBehaviour
{
    [ContextMenu("Combine Meshes")]
    public void CombineMeshes()
    {
        MeshFilter[] meshFilters = GetComponentsInChildren<MeshFilter>(true);
        var combineInstances = new List<CombineInstance>();

        foreach (var mf in meshFilters)
        {
            if (mf.transform == transform)
                continue;

            CombineInstance ci = new CombineInstance
            {
                mesh = mf.sharedMesh,
                transform = transform.worldToLocalMatrix * mf.transform.localToWorldMatrix
            };

            combineInstances.Add(ci);
            mf.gameObject.SetActive(false);
        }

        Mesh combinedMesh = new Mesh();
        combinedMesh.name = "CombinedMesh";
        combinedMesh.CombineMeshes(combineInstances.ToArray(), true, true);

        MeshFilter meshFilter = GetComponent<MeshFilter>();
        meshFilter.sharedMesh = combinedMesh;

        gameObject.SetActive(true);

        Debug.Log("Meshes combined successfully!");
    }
}
