using UnityEngine;
using UnityEngine.SceneManagement;

namespace FPSRetroKit
{
    public class SceneChanger : MonoBehaviour
    {
        [Header("Scene Settings")]
        public string sceneToLoad = "NextScene";
        public bool changeOnTrigger = true;
        public KeyCode interactionKey = KeyCode.E;

        [Header("Sound Settings")]
        public AudioClip transitionSound;
        private AudioSource audioSource;
        private bool playerIsNear = false;

        void Start()
        {
            audioSource = GetComponent<AudioSource>();
            if (audioSource == null) audioSource = gameObject.AddComponent<AudioSource>();
            audioSource.playOnAwake = false;
        }

        void Update()
        {
            // If the player is near and it's key-based switching
            if (playerIsNear && Input.GetKeyDown(interactionKey) && !changeOnTrigger)
            {
                ChangeScene();
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                playerIsNear = true;
                if (changeOnTrigger)
                {
                    ChangeScene();
                }
                else
                {
                    Debug.Log("Press 'E' to change the scene.");
                }
            }
        }

        private void OnTriggerExit(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                playerIsNear = false;
            }
        }

        private void ChangeScene()
        {
            if (transitionSound != null) audioSource.PlayOneShot(transitionSound);

            Debug.Log($"Changing scene to: {sceneToLoad}");

            // Subscribe to the sceneLoaded callback so we can position the player AFTER the scene has loaded
            SceneManager.sceneLoaded += OnSceneLoaded;

            if (transitionSound != null)
            {
                // Delay actual scene load so we can hear the transition sound
                Invoke(nameof(LoadScene), transitionSound.length);
            }
            else
            {
                LoadScene();
            }
        }

        private void LoadScene()
        {
            SceneManager.LoadScene(sceneToLoad);
        }

        /// <summary>
        /// Called automatically by Unity after the new scene is fully loaded.
        /// </summary>
        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            // Make sure we only do this once
            SceneManager.sceneLoaded -= OnSceneLoaded;

            // 1) Find the SceneStartPoint in the newly loaded scene
            SceneStartPoint startPoint = FindObjectOfType<SceneStartPoint>();
            if (startPoint == null)
            {
                Debug.LogWarning("[SceneChanger] No SceneStartPoint found in the new scene!");
                return;
            }

            // 2) Ask the SceneStartPoint to place the player
            //    (We assume it has a public method for that, or automatically does it in its own Start()).
            startPoint.PlacePlayerHere();

            Debug.Log("[SceneChanger] Player has been positioned at the SceneStartPoint in the new scene.");
        }
    }
}
