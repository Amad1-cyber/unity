using UnityEngine;
using System.Collections.Generic;

namespace FPSRetroKit
{
    [System.Serializable]
    public class Quest
    {
        public string title;
        public string description;
        public List<GameObject> devilTargets;  // Specific devil GameObjects that must be defeated
        public float xpReward;                 // XP awarded on quest completion
        public bool isCompleted = false;       // Whether the quest is complete

        // Returns how many devil targets are defeated (i.e. are null)
        public int GetDefeatedCount()
        {
            int count = 0;
            foreach (GameObject d in devilTargets)
            {
                if (d == null)
                    count++;
            }
            return count;
        }

        // Returns total number of devil targets assigned
        public int GetTotalCount()
        {
            return devilTargets.Count;
        }
    }

    public class QuestManager : MonoBehaviour
    {
        public List<Quest> activeQuests = new List<Quest>();

        // Reference to the player's health script (used to award XP)
        public PlayerHealth playerHealth;

        // Reference to the Quest UI for updating progress
        public QuestUI questUI;

        /// <summary>
        /// Adds a new quest by receiving a list of devil targets.
        /// </summary>
        public void AddQuest(string title, string desc, List<GameObject> devilsList, float xp)
        {
            Quest newQuest = new Quest
            {
                title = title,
                description = desc,
                devilTargets = new List<GameObject>(devilsList),
                xpReward = xp,
                isCompleted = false
            };

            activeQuests.Add(newQuest);
            Debug.Log($"[QuestManager] New quest '{title}' added. {devilsList.Count} devils to defeat. Reward: {xp} XP");

            if (questUI != null)
            {
                questUI.RefreshQuestUI(activeQuests);
            }
        }

        /// <summary>
        /// Call this method when a devil is defeated. Pass the devil's GameObject.
        /// </summary>
        public void OnDevilDefeated(GameObject devil)
        {
            foreach (Quest q in activeQuests)
            {
                if (!q.isCompleted && q.devilTargets != null && q.devilTargets.Contains(devil))
                {
                    int index = q.devilTargets.IndexOf(devil);
                    if (index >= 0)
                    {
                        // Mark this devil as defeated by setting its reference to null.
                        q.devilTargets[index] = null;
                    }

                    int defeated = q.GetDefeatedCount();
                    int total = q.GetTotalCount();
                    Debug.Log($"[QuestManager] '{q.title}' progress: {defeated}/{total}");

                    if (defeated >= total)
                    {
                        q.isCompleted = true;
                        Debug.Log($"[QuestManager] Quest '{q.title}' completed! Awarding {q.xpReward} XP.");

                        if (playerHealth != null)
                        {
                            playerHealth.AddExperience(q.xpReward);
                        }
                        if (questUI != null)
                        {
                            questUI.ShowQuestCompleteMessage(q.title);
                        }
                    }
                }
            }

            if (questUI != null)
            {
                questUI.RefreshQuestUI(activeQuests);
            }
        }
    }
}
