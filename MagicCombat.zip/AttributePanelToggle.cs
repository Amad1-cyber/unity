using UnityEngine;

public class AttributePanelToggle : MonoBehaviour
{
    [Header("UI Reference")]
    public GameObject attributePanel; // Assign your panel in the Inspector

    void Update()
    {
        // Press the '1' key on the main keyboard row
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            ToggleAttributePanel();
        }
    }

    void ToggleAttributePanel()
    {
        if (attributePanel != null)
        {
            // Toggle the active state
            bool isActive = attributePanel.activeSelf;
            attributePanel.SetActive(!isActive);

            Debug.Log("Attribute Panel Toggled. Now " + (!isActive ? "Open" : "Closed"));
        }
        else
        {
            Debug.LogWarning("attributePanel is not assigned in the Inspector!");
        }
    }
}
