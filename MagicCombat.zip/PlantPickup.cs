using UnityEngine;
using FPSRetroKit;  // Make sure your namespace matches for PlantCollector

public class PlantPickup : MonoBehaviour
{
    [Header("Plant Pickup Settings")]
    [Tooltip("Sound to play when the plant is picked up.")]
    public AudioClip pickupSound;

    private AudioSource audioSource;
    private bool playerInRange = false;  // True when the player is nearby

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
            audioSource = gameObject.AddComponent<AudioSource>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
            Debug.Log("Plant is in range. Press E to pick up.");
            // Optionally, show a UI prompt here
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
            // Optionally hide the UI prompt here
        }
    }

    void Update()
    {
        // Only pick up when player is in range and the "E" key is pressed.
        if (playerInRange && Input.GetKeyDown(KeyCode.E))
        {
            CollectPlant();
        }
    }

    void CollectPlant()
    {
        if (PlantCollector.Instance != null)
        {
            PlantCollector.Instance.AddPlant();
        }

        if (pickupSound != null && audioSource != null)
        {
            audioSource.PlayOneShot(pickupSound);
        }

        Destroy(gameObject);
    }
}
