using UnityEngine;

namespace FPSRetroKit
{
    public class SceneStartPoint : MonoBehaviour
    {
        [Header("Player Tag")]
        public string playerTag = "Player";

        public void PlacePlayerHere()
        {
            // Find the player in the scene
            GameObject playerObj = GameObject.FindGameObjectWithTag(playerTag);
            if (playerObj == null)
            {
                Debug.LogWarning("[SceneStartPoint] No Player found in the scene!");
                return;
            }

            // Set the player's position and rotation to this start point
            playerObj.transform.position = transform.position;
            playerObj.transform.rotation = transform.rotation;

            Debug.Log($"[SceneStartPoint] Placed {playerObj.name} at {transform.position}");
        }
    }
}
