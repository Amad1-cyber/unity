﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI; // Import for UI Text components

namespace FPSRetroKit
{
    public class FireBallShooter : MonoBehaviour
    {
        [Header("Fireball Settings")]
        public GameObject fireBallPrefab;
        public GameObject spawnPoint;
        public float fireballForce = 20f;
        public float fireballDamage = 25f;
        public float manaCost = 20f;  // Amount of mana to use per fireball

        [Header("Mana Regeneration Settings")]
        public float manaRegenRate = 5f; // Amount of mana regenerated per second
        public float maxMana = 100f; // Max mana for the player
        private float currentMana; // Current mana the player has

        [Header("UI Elements")]
        public Text manaText; // UI Text element to display current mana (drag the Text UI element here in the Inspector)

        [Header("Sounds")]
        public AudioClip fireSound;
        public AudioClip reloadSound;
        public AudioClip noManaSound;

        private AudioSource audioSource;
        private bool isRecharging = false;

        void Start()
        {
            audioSource = GetComponent<AudioSource>();
            currentMana = maxMana; // Initialize mana to maxMana at start
            StartCoroutine(ManaRegeneration()); // Start the regeneration coroutine
            UpdateManaUI(); // Update the UI at the start
        }

        void Update()
        {
            HandleInput();
            UpdateManaUI();
        }

        private void HandleInput()
        {
            // Check if fire1 button (usually mouse or left-click) is pressed
            if (Input.GetButtonDown("Fire1"))
            {
                if (currentMana >= manaCost && !isRecharging)
                {
                    ShootFireball(); // If enough mana, shoot fireball
                }
                else if (currentMana < manaCost && !isRecharging)
                {
                    // Play no mana sound if not enough mana
                    audioSource.PlayOneShot(noManaSound);
                }
            }
        }

        private void ShootFireball()
        {
            // Reduce mana when shooting the fireball
            currentMana -= manaCost;  // Reduce currentMana by manaCost
            UpdateManaUI();  // Update the UI after mana change

            // Instantiate the fireball prefab and apply force to it
            GameObject fireBall = Instantiate(fireBallPrefab, spawnPoint.transform.position, Quaternion.identity);
            Rigidbody fireBallRb = fireBall.GetComponent<Rigidbody>();
            fireBallRb.AddForce(Camera.main.transform.forward * fireballForce, ForceMode.Impulse);

            audioSource.PlayOneShot(fireSound); // Play fire sound effect

            // If mana runs out, start the recharge process
            if (currentMana <= 0 && !isRecharging)
            {
                StartCoroutine(RechargeMana());
            }
        }

        private IEnumerator RechargeMana()
        {
            isRecharging = true;
            audioSource.PlayOneShot(reloadSound); // Play reload sound when mana is being recharged

            while (currentMana < maxMana)
            {
                currentMana += Time.deltaTime * 10; // Recharge rate (can adjust)
                UpdateManaUI(); // Update UI for mana during recharge
                yield return null;
            }

            currentMana = maxMana; // Ensure mana doesn't exceed max
            UpdateManaUI(); // Update UI after recharge is complete
            isRecharging = false; // Stop recharge once full mana is restored
        }

        private void UpdateManaUI()
        {
            // Make sure to update the UI to reflect the current mana
            if (manaText != null)  // Ensure the manaText UI component is assigned
            {
                manaText.text = $"Mana: {currentMana}/{maxMana}";
            }
        }

        // Method to restore mana from the Mana Orb
        public void RestoreMana(float amount)
        {
            currentMana += amount; // Add mana from the orb
            currentMana = Mathf.Clamp(currentMana, 0, maxMana); // Ensure it doesn't exceed maxMana
            UpdateManaUI(); // Update UI after restoring mana
        }

        // Coroutine for mana regeneration over time
        private IEnumerator ManaRegeneration()
        {
            while (true)
            {
                // Regenerate mana over time if it’s not full
                if (currentMana < maxMana)
                {
                    currentMana += manaRegenRate * Time.deltaTime;
                    currentMana = Mathf.Clamp(currentMana, 0, maxMana); // Ensure mana doesn't exceed max
                    UpdateManaUI(); // Update UI for mana
                }

                yield return null;
            }
        }
    }
}
