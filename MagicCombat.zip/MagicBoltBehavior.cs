using UnityEngine;
using Debug = UnityEngine.Debug;

namespace FPSRetroKit
{
    public class MagicBoltBehavior : MonoBehaviour
    {
        public int damage = 25;

        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Enemy"))
            {
                EnemyAI enemy = other.GetComponent<EnemyAI>();
                if (enemy != null)
                {
                    enemy.TakeDamage(damage);
                    Debug.Log($"Magic Bolt hit enemy for {damage} damage.");
                }
                Destroy(gameObject);
            }
        }
    }
}
