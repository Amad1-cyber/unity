using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

namespace FPSRetroKit
{
    public class QuestUI : MonoBehaviour
    {
        [Header("Quest Panel")]
        public GameObject questPanel;    // Parent panel containing the quest list text
        public Text questListText;       // Displays active quests and progress

        [Header("Completion Popup")]
        public GameObject completionPanel;    // Panel shown when a quest completes
        public Text completionMessageText;    // Text for the completion message

        void Start()
        {
            if (questPanel != null)
                questPanel.SetActive(true);
            if (completionPanel != null)
                completionPanel.SetActive(false);
        }

        /// <summary>
        /// Refreshes the quest list display.
        /// </summary>
        public void RefreshQuestUI(List<Quest> activeQuests)
        {
            if (questListText == null)
                return;

            questListText.text = "";
            foreach (Quest q in activeQuests)
            {
                int defeated = q.GetDefeatedCount();
                int total = q.GetTotalCount();
                string status = q.isCompleted ? "(COMPLETED)" : $"({defeated}/{total})";
                questListText.text += $"{q.title} {status}\n";
            }
        }

        /// <summary>
        /// Displays a popup when a quest is completed.
        /// </summary>
        public void ShowQuestCompleteMessage(string questTitle)
        {
            if (completionPanel != null)
            {
                completionPanel.SetActive(true);
                if (completionMessageText != null)
                {
                    completionMessageText.text = $"Quest '{questTitle}' completed!\nThe writ has been granted!";
                }
                Invoke(nameof(HideCompletionPanel), 4f);
            }
        }

        private void HideCompletionPanel()
        {
            if (completionPanel != null)
                completionPanel.SetActive(false);
        }
    }
}
