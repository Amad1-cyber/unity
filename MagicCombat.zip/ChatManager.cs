using System.Collections.Generic;
using Mirror;
using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public class ChatManager : NetworkBehaviour
    {
        public static ChatManager Instance;

        [Header("UI References")]
        [Tooltip("Text element that displays the chat log.")]
        public Text chatText;

        [Tooltip("InputField for entering chat messages.")]
        public InputField chatInputField;

        [Header("Settings")]
        [Tooltip("Maximum number of messages to keep in the chat log.")]
        public int maxMessages = 50;

        // Internal list to hold messages.
        private List<string> messages = new List<string>();

        void Awake()
        {
            // Singleton assignment
            if (Instance == null)
            {
                Instance = this;
            }
            else
            {
                Destroy(gameObject);
            }
        }

        // Called by the local player to send a chat message.
        public void OnSendChatMessage()
        {
            if (chatInputField != null && !string.IsNullOrEmpty(chatInputField.text))
            {
                // Send the message to the server.
                CmdSendChatMessage(chatInputField.text);
                chatInputField.text = "";
            }
        }

        // Command: Runs on the server when a client sends a message.
        [Command]
        void CmdSendChatMessage(string message)
        {
            // You can add additional info such as player name here.
            string finalMessage = $"Player {connectionToClient.connectionId}: {message}";
            RpcReceiveChatMessage(finalMessage);
        }

        // ClientRpc: Runs on all clients to update the chat log.
        [ClientRpc]
        void RpcReceiveChatMessage(string message)
        {
            AddMessage(message);
        }

        /// <summary>
        /// Adds a new message to the chat log.
        /// </summary>
        public void AddMessage(string message)
        {
            messages.Add(message);
            if (messages.Count > maxMessages)
            {
                messages.RemoveAt(0);
            }
            UpdateChatUI();
        }

        /// <summary>
        /// Updates the UI text of the chat log.
        /// </summary>
        void UpdateChatUI()
        {
            if (chatText != null)
            {
                chatText.text = string.Join("\n", messages);
            }
        }

        /// <summary>
        /// Public method to log damage events into the chat log.
        /// Call this from damage-dealing code.
        /// </summary>
        public void LogDamageEvent(string damageInfo)
        {
            AddMessage(damageInfo);
        }
    }
}
