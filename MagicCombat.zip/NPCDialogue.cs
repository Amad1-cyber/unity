using UnityEngine;
using System.Collections.Generic;

namespace FPSRetroKit
{
    public class NPCDialogue : MonoBehaviour
    {
        [Header("Dialogue Lines")]
        public string[] dialogueLines = new string[]
        {
            "NPC: Hello, what is going on?",
            "NPC: Your land has been sieged by the devils...",
            "Player: What am I to do?",
            "NPC: You must defeat all of them to gain the writ of land ownership back.",
            "Player: I will do it."
        };

        [Header("Quest Info")]
        public string questTitle = "Right of Land Ownership Retrieval";
        public string questDescription = "Defeat 10 devils to reclaim your land!";
        public float xpReward = 500f;

        // Instead of an int, provide a list of devil GameObjects (assign in Inspector or find by tag)
        public List<GameObject> devilTargets;

        [Header("Interaction Settings")]
        public KeyCode interactionKey = KeyCode.E;
        public DialogueUI dialogueUI;  // Reference to your DialogueUI script
        private bool playerIsNear = false;
        private bool questGiven = false;

        void Update()
        {
            if (playerIsNear && Input.GetKeyDown(interactionKey))
            {
                StartDialogue();
            }
        }

        private void StartDialogue()
        {
            if (dialogueUI != null && !dialogueUI.IsDialogueActive())
            {
                dialogueUI.StartDialogue(dialogueLines, OnDialogueComplete);
            }
        }

        private void OnDialogueComplete()
        {
            Debug.Log("[NPCDialogue] Dialogue complete!");
            if (!questGiven)
            {
                questGiven = true;
                QuestManager questManager = FindObjectOfType<QuestManager>();
                if (questManager != null)
                {
                    // Pass the list of devils instead of an int
                    questManager.AddQuest(questTitle, questDescription, devilTargets, xpReward);
                }
                else
                {
                    Debug.LogWarning("[NPCDialogue] No QuestManager found!");
                }
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                playerIsNear = true;
                Debug.Log("[NPCDialogue] Press 'E' to talk to NPC.");
            }
        }

        private void OnTriggerExit(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                playerIsNear = false;
            }
        }
    }
}
