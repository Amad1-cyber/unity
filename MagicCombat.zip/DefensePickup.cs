using UnityEngine;
using FPSRetroKit; // For PlayerDataManager

public class DefensePickup : MonoBehaviour
{
    [Header("Defense Increase Settings")]
    [Tooltip("Amount to increase the player's defense.")]
    public int defenseIncreaseAmount = 5;

    [Header("Appearance Change Settings")]
    [Tooltip("Sprite representing the holy yellow shirt.")]
    public Sprite holyYellowShirtSprite;
    [Tooltip("Optional: Assign the player's clothing SpriteRenderer (if not, the script will try to find one on the Player).")]
    public SpriteRenderer playerClothingRenderer;

    [Header("Pickup Sound")]
    [Tooltip("Sound to play when the pickup is collected.")]
    public AudioClip pickupSound;

    private AudioSource audioSource;

    void Start()
    {
        // Try to get an AudioSource component; if not found, add one.
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
            audioSource = gameObject.AddComponent<AudioSource>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            // Increase the player's defense via the PlayerDataManager singleton.
            if (PlayerDataManager.Instance != null)
            {
                PlayerDataManager.Instance.defense += defenseIncreaseAmount;
                Debug.Log("Defense increased by " + defenseIncreaseAmount + ". New defense: " + PlayerDataManager.Instance.defense);
            }
            else
            {
                Debug.LogWarning("PlayerDataManager not found!");
            }

            // Change player's appearance to the holy yellow shirt.
            // If a SpriteRenderer reference is assigned, use it.
            if (playerClothingRenderer != null && holyYellowShirtSprite != null)
            {
                playerClothingRenderer.sprite = holyYellowShirtSprite;
            }
            else
            {
                // Otherwise, try to find a SpriteRenderer in the player's children.
                SpriteRenderer sr = other.GetComponentInChildren<SpriteRenderer>();
                if (sr != null && holyYellowShirtSprite != null)
                {
                    sr.sprite = holyYellowShirtSprite;
                }
            }

            // Play the pickup sound, if assigned.
            if (pickupSound != null && audioSource != null)
            {
                audioSource.PlayOneShot(pickupSound);
            }

            // Destroy the pickup after a short delay (to allow the sound to play).
            Destroy(gameObject, 0.2f);
        }
    }
}
