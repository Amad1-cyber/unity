﻿using UnityEngine;

namespace FPSRetroKit
{
    public class Enemy : MonoBehaviour
    {
        [Header("Enemy Stats")]
        public int maxHealth = 100;
        private float health;
        private bool isDead = false;

        [Header("Death Effects")]
        public GameObject deathEffectPrefab; // Optional: Visual effect on death
        public AudioClip deathSound; // Optional: Sound effect on death

        private AudioSource audioSource;

        // Public Property for Health
        public float Health
        {
            get { return health; }
            set
            {
                health = Mathf.Clamp(value, 0, maxHealth);
                if (health <= 0 && !isDead)
                {
                    Die();
                }
            }
        }

        void Start()
        {
            Health = maxHealth;
            audioSource = GetComponent<AudioSource>();
        }

        // Call this method to deal damage to the enemy
        public void TakeDamage(float damage)
        {
            if (isDead) return; // Prevent damage after death

            Health -= damage;
            UnityEngine.Debug.Log($"Enemy took {damage} damage. Remaining health: {Health}.");
        }

        private void Die()
        {
            isDead = true;
            UnityEngine.Debug.Log("Enemy defeated!");

            // Play death sound if available
            if (deathSound != null && audioSource != null)
            {
                audioSource.PlayOneShot(deathSound);
            }

            // Instantiate death visual effect
            if (deathEffectPrefab != null)
            {
                Instantiate(deathEffectPrefab, transform.position, Quaternion.identity);
            }

            // Disable the enemy to prevent further interactions
            GetComponent<Collider>().enabled = false;
            GetComponent<MeshRenderer>().enabled = false;

            // Destroy the enemy after a short delay
            Destroy(gameObject, 2f);
        }
    }
}
