using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public class HitTypeManager : MonoBehaviour
    {
        public static bool IsGoodnessHit = true;

        [Header("Effect Prefabs")]
        public GameObject goodnessPrefab;
        public GameObject deadlyPrefab;

        [Header("UI Components")]
        public Text hitTypeText;

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Alpha9)) // Toggle to Goodness Hit
            {
                IsGoodnessHit = true;
                UpdateHitTypeUI("Goodness Hit");
            }
            else if (Input.GetKeyDown(KeyCode.Alpha0)) // Toggle to Deadly Hit
            {
                IsGoodnessHit = false;
                UpdateHitTypeUI("Deadly Hit");
            }
        }

        public void InstantiateEffect(Vector3 position)
        {
            GameObject effectPrefab = IsGoodnessHit ? goodnessPrefab : deadlyPrefab;
            Instantiate(effectPrefab, position, Quaternion.identity);
        }

        private void UpdateHitTypeUI(string hitType)
        {
            if (hitTypeText != null)
            {
                hitTypeText.text = hitType;
            }
            else
            {
                Debug.LogError("HitType Text UI component is not assigned in the inspector!");
            }
        }
    }
}
