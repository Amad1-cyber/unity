using UnityEngine;

namespace FPSRetroKit
{
    public class HandController : MonoBehaviour
    {
        [Header("Hand Settings")]
        public GameObject magicHand; // The hand object
        public Transform handAnchor; // A Transform acting as the anchor for the hand

        [Header("Magic Bolt Settings")]
        public GameObject magicBoltPrefab; // The MagicBolt prefab
        public Transform spawnPoint; // Spawn point for bolts
        public float fireRate = 0.5f; // Fire rate of the bolts
        private float nextFireTime = 0f;

        private Transform cameraTransform;

        void Start()
        {
            // Get the main camera's transform
            cameraTransform = Camera.main.transform;

            EnableMagicHand();
        }

        void Update()
        {
            HandleHandPosition();
            HandleInput();
        }

        private void HandleHandPosition()
        {
            // Make hand follow the camera
            if (Camera.main != null)
            {
                transform.position = Camera.main.transform.position + Camera.main.transform.forward * 1.0f; // Adjust Z-axis
                transform.position += Camera.main.transform.up * -0.2f; // Adjust downwards slightly
                transform.rotation = Camera.main.transform.rotation; // Align rotation with the camera
            }
        }

        private void HandleInput()
        {
            if (magicHand.activeSelf && Input.GetMouseButton(0) && Time.time >= nextFireTime)
            {
                ShootMagicBolt();
                nextFireTime = Time.time + fireRate;
            }
        }

        private void ShootMagicBolt()
        {
            Instantiate(magicBoltPrefab, spawnPoint.position, spawnPoint.rotation);
            UnityEngine.Debug.Log("Magic Bolt Fired!"); // Explicitly use UnityEngine.Debug
        }

        public void EnableMagicHand()
        {
            magicHand.SetActive(true);
        }
    }
}
