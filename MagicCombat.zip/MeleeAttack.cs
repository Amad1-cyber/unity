using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public class MeleeAttack : MonoBehaviour
    {
        [Header("Melee Mode Settings")]
        [Tooltip("Press the '2' key to toggle melee mode.")]
        public KeyCode toggleMeleeKey = KeyCode.Alpha2;

        [Header("Punch Animation Settings")]
        [Tooltip("Sequence of sprites to animate the fists (e.g. left punch, right punch, etc.).")]
        public Sprite[] punchSprites;
        [Tooltip("UI Image that will display the melee animation. (Place this on your Canvas.)")]
        public Image meleeImage;
        [Tooltip("Time (in seconds) each frame is shown.")]
        public float animationFrameRate = 0.1f;

        [Header("Melee Combat Settings")]
        [Tooltip("Damage dealt per melee attack.")]
        public int meleeDamage = 30;
        [Tooltip("Range for the melee attack (raycast from the camera).")]
        public float meleeRange = 3f;

        private bool isMeleeMode = false;
        private bool isPunching = false;

        void Update()
        {
            // Toggle between melee and magic modes using key '2'
            if (Input.GetKeyDown(toggleMeleeKey))
            {
                isMeleeMode = !isMeleeMode;
                Debug.Log("Melee Mode: " + (isMeleeMode ? "Enabled" : "Disabled"));
            }

            // If in melee mode and not currently punching, check for attack input
            if (isMeleeMode && !isPunching)
            {
                if (Input.GetMouseButtonDown(0))
                {
                    StartCoroutine(PerformMeleeAttack());
                }
            }
        }

        private IEnumerator PerformMeleeAttack()
        {
            isPunching = true;

            // Optional: perform a raycast from the main camera forward
            RaycastHit hit;
            Camera cam = Camera.main;
            if (cam != null && Physics.Raycast(cam.transform.position, cam.transform.forward, out hit, meleeRange))
            {
                // Check if we hit an enemy (make sure enemy objects are tagged "Enemy")
                if (hit.collider.CompareTag("Enemy"))
                {
                    // Try to get the enemy component and apply melee damage
                    EnemyAI_3D enemy = hit.collider.GetComponent<EnemyAI_3D>();
                    if (enemy != null)
                    {
                        enemy.TakeDamage(meleeDamage);
                        Debug.Log("Melee hit " + enemy.gameObject.name + " for " + meleeDamage + " damage.");
                    }
                }
            }

            // Animate the punch sequence
            // Assumes punchSprites array holds the sequence (e.g., first frame left punch, second frame right punch)
            for (int i = 0; i < punchSprites.Length; i++)
            {
                if (meleeImage != null)
                    meleeImage.sprite = punchSprites[i];

                yield return new WaitForSeconds(animationFrameRate);
            }

            // Optionally, reset the melee image (or set to an idle fist sprite)
            if (meleeImage != null)
                meleeImage.sprite = null;

            isPunching = false;
        }
    }
}
