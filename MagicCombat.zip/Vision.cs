﻿using UnityEngine;

namespace FPSRetroKit
{
    public class Vision : MonoBehaviour
    {
        private MagicAttack magicAttack;

        void Start()
        {
            magicAttack = GetComponent<MagicAttack>(); // Ensure MagicAttack script is referenced
            if (magicAttack == null)
            {
                Debug.LogError("❌ MagicAttack component is missing on this object!");
            }
        }

        public void UseMagic()
        {
            if (magicAttack != null)
            {
                magicAttack.CastFireBolt();
            }
            else
            {
                Debug.LogError("⚠ MagicAttack script not found on enemy!");
            }
        }
    }
}
