﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public enum CombatMode
    {
        Melee,
        Search,
        Magic
    }

    public class CombatPeaceManager : MonoBehaviour
    {
        [Header("General Settings")]
        public CombatMode currentCombatMode = CombatMode.Melee;
        public bool isPeaceMode = false;
        public KeyCode peaceToggleKey = KeyCode.P;
        public KeyCode holyWaterDrinkKey = KeyCode.K;

        [Header("References")]
        public GameObject handObject;         // The first-person hand object (with a SpriteRenderer)
        public GameObject holyWaterPanel;     // Panel shown in Peace Mode
        public Camera playerCamera;

        [Header("Combat Settings - Melee")]
        public Animator meleeAnimator;
        public RuntimeAnimatorController meleeAnimController;
        public Sprite meleeIdleSprite;
        public Sprite holyMeleeIdleSprite;    // Holy variant for melee (e.g. yellow shirted fists)
        public int meleeDamage = 40;
        public float meleeRange = 2.5f;
        public float meleeDamageDelay = 0.3f;
        public AudioClip meleeSound;

        [Header("Combat Settings - Magic")]
        public GameObject magicProjectilePrefab;
        public Transform magicSpawnPoint;
        public float magicProjectileSpeed = 20f;
        public float magicDamage = 25f;
        public float magicManaCost = 20f;
        public AudioClip magicSound;

        [Header("Combat Settings - Search")]
        public float searchRange = 3f;

        [Header("Mana Settings")]
        public float maxMana = 100f;
        public float manaRegenRate = 5f;
        private float currentMana;

        [Header("Idle Sprites for Combat Modes")]
        public Sprite searchIdleSprite;
        public Sprite magicIdleSprite;

        [Header("Holy Water Settings")]
        public int holyWaterUses = 5;
        public float holyWaterTimeLimit = 120f;
        private float holyWaterTimer = 0f;
        public AudioClip drinkSound;
        public SpriteRenderer holyWaterSpriteRenderer;
        public Sprite holyWaterIdleSprite;
        public Sprite[] holyWaterDrinkSprites;
        public float holyWaterFrameRate = 0.1f;

        [Header("Walking Sound")]
        public AudioClip walkingSound;

        private AudioSource audioSource;

        void Start()
        {
            if (playerCamera == null)
                playerCamera = Camera.main;

            currentMana = maxMana;
            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
                audioSource = gameObject.AddComponent<AudioSource>();

            SetModeActive(isPeaceMode);

            if (meleeAnimator != null && meleeAnimController != null)
                meleeAnimator.runtimeAnimatorController = meleeAnimController;

            UpdateIdleSprite();
        }

        void Update()
        {
            // Toggle Peace Mode.
            if (Input.GetKeyDown(peaceToggleKey))
            {
                isPeaceMode = !isPeaceMode;
                if (isPeaceMode)
                    holyWaterTimer = 0f;
                SetModeActive(isPeaceMode);
                Debug.Log("Peace Mode: " + isPeaceMode);
            }

            if (isPeaceMode)
            {
                holyWaterTimer += Time.deltaTime;
                if (holyWaterTimer >= holyWaterTimeLimit)
                {
                    Debug.Log("Holy water expired.");
                    if (holyWaterPanel != null)
                        holyWaterPanel.SetActive(false);
                }
                if (Input.GetKeyDown(holyWaterDrinkKey))
                {
                    if (holyWaterUses > 0)
                        StartCoroutine(DrinkHolyWater());
                    else
                        Debug.Log("No holy water uses left.");
                }
                return;
            }

            // Walking sound.
            if (Mathf.Abs(Input.GetAxis("Horizontal")) > 0.1f || Mathf.Abs(Input.GetAxis("Vertical")) > 0.1f)
            {
                if (!audioSource.isPlaying || audioSource.clip != walkingSound)
                {
                    audioSource.clip = walkingSound;
                    audioSource.loop = true;
                    audioSource.Play();
                }
            }
            else
            {
                if (audioSource.clip == walkingSound)
                    audioSource.Stop();
            }

            // Mode switching via number keys.
            if (Input.GetKeyDown(KeyCode.Alpha1))
            {
                currentCombatMode = CombatMode.Melee;
                UpdateIdleSprite();
            }
            else if (Input.GetKeyDown(KeyCode.Alpha2))
            {
                currentCombatMode = CombatMode.Search;
                UpdateIdleSprite();
            }
            else if (Input.GetKeyDown(KeyCode.Alpha3))
            {
                currentCombatMode = CombatMode.Magic;
                UpdateIdleSprite();
            }

            // Process combat actions.
            switch (currentCombatMode)
            {
                case CombatMode.Melee:
                    if (Input.GetButtonDown("Fire1"))
                    {
                        if (meleeAnimator != null)
                            meleeAnimator.SetTrigger("Attack");
                        if (meleeSound != null)
                            audioSource.PlayOneShot(meleeSound);
                        StartCoroutine(DelayedMeleeDamage());
                    }
                    break;
                case CombatMode.Search:
                    if (Input.GetKeyDown(KeyCode.E))
                        PerformSearchInteract();
                    break;
                case CombatMode.Magic:
                    if (Input.GetButtonDown("Fire1"))
                    {
                        if (currentMana >= magicManaCost)
                        {
                            CastMagic();
                            currentMana -= magicManaCost;
                            if (magicSound != null)
                                audioSource.PlayOneShot(magicSound);
                        }
                        else
                        {
                            Debug.Log("Not enough mana! " + currentMana);
                        }
                    }
                    break;
            }

            // Regenerate mana.
            if (currentMana < maxMana)
            {
                currentMana += manaRegenRate * Time.deltaTime;
                currentMana = Mathf.Clamp(currentMana, 0f, maxMana);
            }
        }

        void SetModeActive(bool peace)
        {
            if (peace)
            {
                if (handObject != null)
                    handObject.SetActive(false);
                if (holyWaterPanel != null)
                    holyWaterPanel.SetActive(true);
                if (holyWaterSpriteRenderer != null && holyWaterIdleSprite != null)
                    holyWaterSpriteRenderer.sprite = holyWaterIdleSprite;
            }
            else
            {
                if (handObject != null)
                    handObject.SetActive(true);
                if (holyWaterPanel != null)
                    holyWaterPanel.SetActive(false);
            }
        }

        public void UpdateIdleSprite()
        {
            if (handObject == null) return;
            SpriteRenderer sr = handObject.GetComponent<SpriteRenderer>();
            if (sr == null) return;

            bool hasHoly = (PlayerDataManager.Instance != null && PlayerDataManager.Instance.hasHolyShirt);

            switch (currentCombatMode)
            {
                case CombatMode.Melee:
                    sr.sprite = (hasHoly && holyMeleeIdleSprite != null) ? holyMeleeIdleSprite : meleeIdleSprite;
                    break;
                case CombatMode.Search:
                    sr.sprite = searchIdleSprite;
                    break;
                case CombatMode.Magic:
                    sr.sprite = magicIdleSprite;
                    break;
            }
        }

        // Public method so external scripts (like HolyShirtPickup) can force a refresh.
        public void RefreshSpritesImmediately()
        {
            UpdateIdleSprite();
        }

        IEnumerator DelayedMeleeDamage()
        {
            yield return new WaitForSeconds(meleeDamageDelay);
            Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, meleeRange))
            {
                if (hit.collider.CompareTag("Enemy"))
                {
                    Debug.Log("Melee hit " + hit.collider.gameObject.name + " for " + meleeDamage + " damage.");
                    hit.collider.gameObject.SendMessage("TakeDamage", meleeDamage, SendMessageOptions.DontRequireReceiver);
                }
            }
        }

        void PerformSearchInteract()
        {
            Debug.Log("Performing search interaction...");
            Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, searchRange))
            {
                Debug.Log("Interacting with " + hit.collider.gameObject.name);
                hit.collider.gameObject.SendMessage("OnInteract", SendMessageOptions.DontRequireReceiver);
            }
            else
            {
                Debug.Log("No interactable object in range.");
            }
        }

        void CastMagic()
        {
            Debug.Log("Casting magic attack...");
            if (magicProjectilePrefab != null && magicSpawnPoint != null)
            {
                GameObject projectile = Instantiate(magicProjectilePrefab, magicSpawnPoint.position, magicSpawnPoint.rotation);
                Rigidbody rb = projectile.GetComponent<Rigidbody>();
                if (rb != null)
                {
                    rb.linearVelocity = magicSpawnPoint.forward * magicProjectileSpeed;
                }
                FireballBehavior fb = projectile.GetComponent<FireballBehavior>();
                if (fb != null)
                {
                    fb.damage = Mathf.RoundToInt(magicDamage);
                }
            }
            else
            {
                Debug.LogWarning("Magic projectile or spawn point not assigned!");
            }
        }

        IEnumerator DrinkHolyWater()
        {
            Debug.Log("Drinking holy water...");
            if (holyWaterSpriteRenderer != null && holyWaterDrinkSprites != null && holyWaterDrinkSprites.Length > 0)
            {
                for (int i = 0; i < holyWaterDrinkSprites.Length; i++)
                {
                    holyWaterSpriteRenderer.sprite = holyWaterDrinkSprites[i];
                    yield return new WaitForSeconds(holyWaterFrameRate);
                }
                holyWaterSpriteRenderer.sprite = holyWaterIdleSprite;
            }
            else
            {
                yield return new WaitForSeconds(0.5f);
            }

            if (drinkSound != null)
                audioSource.PlayOneShot(drinkSound);

            // Fully restore health and mana.
            PlayerHealth playerHealth = FindObjectOfType<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.RestoreHealth(9999);
                playerHealth.RestoreMana(9999);
                Debug.Log("Holy water consumed: Health and Mana fully restored.");
            }
            else
            {
                Debug.LogWarning("PlayerHealth component not found.");
            }

            holyWaterUses--;
            Debug.Log("Remaining holy water uses: " + holyWaterUses);
            if (holyWaterUses <= 0)
            {
                Debug.Log("Holy water bottle is empty. Destroying holy water panel.");
                Destroy(holyWaterPanel);
            }
        }
    }
}
