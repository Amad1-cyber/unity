﻿using System.Collections.Generic;
using UnityEngine;

namespace FPSRetroKit
{
    public class WeaponSwitch : MonoBehaviour
    {
        [Header("Weapon Settings")]
        [Tooltip("List of weapons (child transforms or manually assigned).")]
        public List<Transform> weapons;

        [Tooltip("Weapon index to start with (0-based).")]
        public int initialWeapon = 0;

        [Tooltip("Automatically fill the weapons list with all child objects.")]
        public bool autoFill = true;

        private int selectedWeapon = 0;

        private void Awake()
        {
            // Auto-fill the list with child weapons if enabled
            if (autoFill)
            {
                weapons.Clear();
                foreach (Transform weapon in transform)
                {
                    weapons.Add(weapon);
                }
            }
        }

        void Start()
        {
            if (weapons == null || weapons.Count == 0)
            {
                Debug.LogError("[WeaponSwitch] No weapons found. Please assign weapons in the Inspector or add child objects.");
                return;
            }

            // Initialize selectedWeapon safely (avoid divide-by-zero)
            selectedWeapon = initialWeapon % weapons.Count;
            UpdateWeapon();
        }

        void Update()
        {
            // If there are no weapons, exit early.
            if (weapons == null || weapons.Count == 0)
                return;

            // Mouse scroll to change weapon.
            if (Input.GetAxis("Mouse ScrollWheel") > 0)
                selectedWeapon = (selectedWeapon + 1) % weapons.Count;
            if (Input.GetAxis("Mouse ScrollWheel") < 0)
                selectedWeapon = (selectedWeapon - 1 + weapons.Count) % weapons.Count;

            // Keyboard shortcuts to select a weapon (1, 2, 3)
            if (Input.GetKeyDown(KeyCode.Alpha1))
                selectedWeapon = 0;
            if (Input.GetKeyDown(KeyCode.Alpha2) && weapons.Count > 1)
                selectedWeapon = 1;
            if (Input.GetKeyDown(KeyCode.Alpha3) && weapons.Count > 2)
                selectedWeapon = 2;

            UpdateWeapon();
        }

        void UpdateWeapon()
        {
            // Enable only the selected weapon and disable others
            for (int i = 0; i < weapons.Count; i++)
            {
                weapons[i].gameObject.SetActive(i == selectedWeapon);
            }
        }
    }
}
