﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace FPSRetroKit
{
    public class PlayerHealth : MonoBehaviour
    {
        private PlayerDataManager data;
        public Transform reincarnationPoint;
        public float reincarnationDelay = 2f;

        [Header("Audio Settings")]
        public AudioClip playerDefeatedSound;
        public AudioClip gotHitSound; // Sound when player is hit.

        [Header("Damage Popup")]
        public GameObject damagePopupPrefab; // Prefab for floating damage text.

        private AudioSource audioSource;

        void Start()
        {
            // Acquire the PlayerDataManager (holds HP, Mana, etc.)
            data = PlayerDataManager.Instance;
            if (data == null)
            {
                Debug.LogError("[PlayerHealth] No PlayerDataManager found!");
                return;
            }

            // Setup AudioSource
            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
                audioSource = gameObject.AddComponent<AudioSource>();

            Debug.Log($"[PlayerHealth] Loaded: Level {data.level}, HP {data.currentHealth}/{data.maxHealth}, XP {data.currentExperience}/{data.experienceToNextLevel}");
        }

        /// <summary>
        /// Add experience to the player, leveling up if needed.
        /// </summary>
        public void AddExperience(float xp)
        {
            if (data == null) return;

            data.currentExperience += xp;
            Debug.Log($"[PlayerHealth] Gained {xp} XP. Now XP: {data.currentExperience}/{data.experienceToNextLevel}");

            // Process possible multiple level-ups
            while (data.currentExperience >= data.experienceToNextLevel)
            {
                data.LevelUp();
            }
        }

        /// <summary>
        /// Called when the player takes damage.
        /// </summary>
        public void TakeDamage(int dmg)
        {
            if (data == null) return;

            // Reduce by player's defense
            int reducedDamage = Mathf.Max(dmg - data.defense, 0);
            data.currentHealth = Mathf.Clamp(data.currentHealth - reducedDamage, 0, data.maxHealth);

            Debug.Log($"[PlayerHealth] Damage taken: {reducedDamage}. HP: {data.currentHealth}/{data.maxHealth}");

            // Play 'got hit' sound
            if (gotHitSound != null)
                audioSource.PlayOneShot(gotHitSound);

            // Optionally spawn a floating damage popup
            if (damagePopupPrefab != null)
            {
                var popup = Instantiate(damagePopupPrefab, transform.position, Quaternion.identity);
                var dmgPopup = popup.GetComponent<DamagePopup>();
                if (dmgPopup != null)
                    dmgPopup.SetDamage(reducedDamage);
            }

            // If health is zero, start reincarnation
            if (data.currentHealth <= 0)
            {
                Debug.Log("[PlayerHealth] Player defeated!");
                if (playerDefeatedSound != null)
                    audioSource.PlayOneShot(playerDefeatedSound);

                StartCoroutine(ReincarnateAfterDelay());
            }
        }

        /// <summary>
        /// Restore some HP.
        /// </summary>
        public void RestoreHealth(int amount)
        {
            if (data == null) return;

            data.currentHealth = Mathf.Clamp(data.currentHealth + amount, 0, data.maxHealth);
            Debug.Log($"[PlayerHealth] Healed {amount}. HP: {data.currentHealth}/{data.maxHealth}");
        }

        /// <summary>
        /// Restore some MP (mana).
        /// </summary>
        public void RestoreMana(int amount)
        {
            if (data == null) return;

            data.currentMana = Mathf.Clamp(data.currentMana + amount, 0, data.maxMana);
            Debug.Log($"[PlayerHealth] Restored {amount} Mana. MP: {data.currentMana}/{data.maxMana}");
        }

        /// <summary>
        /// (Optional) Helper: specifically restore 50 Mana from a 'holy cigarette'.
        /// </summary>
        public void RestoreManaFromCigarette()
        {
            // For convenience, you can do any extra logic here if needed.
            int amount = 50;
            RestoreMana(amount);
            Debug.Log($"[PlayerHealth] Holy cigarette smoked: Restored {amount} Mana.");
        }

        /// <summary>
        /// Reincarnates the player after a short delay.
        /// </summary>
        private IEnumerator ReincarnateAfterDelay()
        {
            yield return new WaitForSeconds(reincarnationDelay);

            // Move the player to the assigned waypoint
            if (reincarnationPoint != null)
            {
                transform.position = reincarnationPoint.position;
                transform.rotation = reincarnationPoint.rotation;
                Debug.Log("[PlayerHealth] Reincarnated at the waypoint.");
            }
            else
            {
                Debug.LogWarning("[PlayerHealth] No reincarnationPoint assigned.");
            }

            // Restore to full health/mana
            data.currentHealth = data.maxHealth;
            data.currentMana = data.maxMana;
        }
    }
}
