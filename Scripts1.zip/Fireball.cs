using UnityEngine;
using FPSRetroKit;

public class Fireball : MonoBehaviour
{
    public int damage = 20;
    public float lifetime = 5f;

    void Start()
    {
        Destroy(gameObject, lifetime);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerHealth playerHealth = other.GetComponent<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.TakeDamage(damage);
                Debug.Log("Fireball hit Player! Damage: " + damage);
            }
            Destroy(gameObject);
        }
        else if (other.CompareTag("Enemy"))
        {
            EnemyAI_3D enemyHealth = other.GetComponent<EnemyAI_3D>();
            if (enemyHealth != null)
            {
                enemyHealth.TakeDamage(damage);
                Debug.Log("Fireball hit Enemy! Damage: " + damage);
            }
            Destroy(gameObject);
        }
    }
}
