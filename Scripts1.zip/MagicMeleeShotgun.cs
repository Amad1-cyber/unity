using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace FPSRetroKit
{
    [RequireComponent(typeof(AudioSource))]
    public class MagicMeleeShotgun : MonoBehaviour
    {
        [Header("Mode Toggle")]
        [Tooltip("Scrolling the mouse wheel toggles between Magic (Shotgun) mode and Melee mode.")]
        public bool isMeleeMode = false;  // Start in Magic mode if false

        [Tooltip("Optional UI Text to show current mode")]
        public Text modeText;

        [Header("Magic/Shotgun Sprites")]
        public Sprite idleShotgun;
        public Sprite shotShotgun;

        [Header("Magic/Shotgun Settings")]
        public float shotgunDamage = 25f;
        public float shotgunRange = 40f;
        public float howLongReload = 2f;
        public AudioClip shotSound;
        public AudioClip reloadSound;
        public AudioClip emptyGunSound;
        public GameObject bulletHoleShotgun;
        public GameObject bloodSplat;
        public int ammoAmount = 8;      // e.g. 8 shells loaded
        public int ammoClipSize = 8;    // e.g. 8 shells max
        public Text ammoText;
        private int ammoLeft;
        private int ammoClipLeft;
        private bool isShot;
        private bool isReloading;

        AudioSource source;
        SpriteRenderer spriteRend; // For displaying shotgun sprite

        [Header("Melee Settings")]
        public int meleeDamage = 40;
        public float meleeRange = 2.5f;
        [Tooltip("Array of sprites for the melee punch animation (cycle left/right fists).")]
        public Sprite[] meleePunchSprites;
        [Tooltip("UI Image used to display the melee animation.")]
        public Image meleeImage;
        public float meleeAnimationFrameRate = 0.1f;

        void Awake()
        {
            source = GetComponent<AudioSource>();
            spriteRend = GetComponent<SpriteRenderer>();  // This object should have a SpriteRenderer
            ammoLeft = ammoAmount;
            ammoClipLeft = ammoClipSize;
        }

        void OnEnable()
        {
            isReloading = false;
        }

        void Start()
        {
            if (meleeImage != null)
                meleeImage.gameObject.SetActive(false);

            UpdateModeText();
        }

        void Update()
        {
            // Toggle modes with mouse scroll
            float scroll = Input.GetAxis("Mouse ScrollWheel");
            if (scroll != 0)
            {
                isMeleeMode = !isMeleeMode;
                Debug.Log("Switched to " + (isMeleeMode ? "Melee Mode" : "Magic (Shotgun) Mode"));
                UpdateModeText();
            }

            // Update ammo UI or display mode text
            if (!isMeleeMode && ammoText != null)
            {
                ammoText.text = "Ammo\n" + ammoClipLeft + " / " + ammoLeft;
            }
            else if (isMeleeMode && ammoText != null)
            {
                ammoText.text = "Melee Mode";
            }

            // Fire input
            if (Input.GetButtonDown("Fire1") && !isReloading)
            {
                if (isMeleeMode)
                {
                    StartCoroutine(PerformMeleeAttack());
                }
                else
                {
                    isShot = true;
                }
            }

            // Reload on R (only in shotgun mode)
            if (Input.GetKeyDown(KeyCode.R) && !isReloading && !isMeleeMode)
            {
                if (ammoClipLeft != ammoClipSize)
                    Reload();
            }
        }

        void FixedUpdate()
        {
            if (isMeleeMode)
                return; // Skip shotgun logic when in melee mode

            // Shotgun (magic) firing logic
            if (isShot && ammoClipLeft > 0 && !isReloading)
            {
                isShot = false;
                ammoClipLeft -= 2; // Shotgun uses 2 shells per shot
                source.PlayOneShot(shotSound);
                StartCoroutine(ShotgunShootAnimation());

                Ray ray = Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0));
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit, shotgunRange))
                {
                    Debug.Log("Shotgun projectile hit " + hit.collider.gameObject.name);
                    hit.collider.gameObject.SendMessage("AddDamage", shotgunDamage, SendMessageOptions.DontRequireReceiver);

                    if (hit.transform.CompareTag("Enemy"))
                    {
                        Instantiate(bloodSplat, hit.point, Quaternion.identity);
                    }
                    else
                    {
                        bulletHoleShotgun.transform.GetChild(0).localScale = new Vector3(0.05f, 0.05f, 0.05f);
                        Instantiate(bulletHoleShotgun, hit.point, Quaternion.FromToRotation(Vector3.up, hit.normal))
                            .transform.parent = hit.collider.gameObject.transform;
                    }
                }
            }
            else if (isShot && ammoClipLeft <= 0 && !isReloading)
            {
                isShot = false;
                Reload();
            }
        }

        void Reload()
        {
            int bulletsToReload = ammoClipSize - ammoClipLeft;
            if (ammoLeft >= bulletsToReload)
            {
                StartCoroutine(ReloadWeapon());
                ammoLeft -= bulletsToReload;
                ammoClipLeft = ammoClipSize;
            }
            else if (ammoLeft < bulletsToReload && ammoLeft > 0)
            {
                StartCoroutine(ReloadWeapon());
                ammoClipLeft += ammoLeft;
                ammoLeft = 0;
            }
            else if (ammoLeft <= 0)
            {
                source.PlayOneShot(emptyGunSound);
            }
        }

        IEnumerator ReloadWeapon()
        {
            isReloading = true;
            source.PlayOneShot(reloadSound);
            yield return new WaitForSeconds(howLongReload);
            isReloading = false;
        }

        IEnumerator ShotgunShootAnimation()
        {
            spriteRend.sprite = shotShotgun;
            yield return new WaitForSeconds(0.5f);
            spriteRend.sprite = idleShotgun;
        }

        // MELEE CODE
        private IEnumerator PerformMeleeAttack()
        {
            Debug.Log("Performing Melee Attack...");
            if (meleeImage != null)
                meleeImage.gameObject.SetActive(true);

            if (meleePunchSprites != null && meleePunchSprites.Length > 0 && meleeImage != null)
            {
                for (int i = 0; i < meleePunchSprites.Length; i++)
                {
                    meleeImage.sprite = meleePunchSprites[i];
                    yield return new WaitForSeconds(meleeAnimationFrameRate);
                }
                meleeImage.sprite = null;
                meleeImage.gameObject.SetActive(false);
            }
            else
            {
                yield return new WaitForSeconds(0.2f);
            }

            // Raycast from center for melee damage
            Ray ray = Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0));
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, meleeRange))
            {
                if (hit.collider.CompareTag("Enemy"))
                {
                    hit.collider.gameObject.SendMessage("AddDamage", meleeDamage, SendMessageOptions.DontRequireReceiver);
                    Debug.Log("Melee hit " + hit.collider.gameObject.name + " for " + meleeDamage + " damage.");
                }
            }
        }

        private void UpdateModeText()
        {
            if (modeText != null)
                modeText.text = isMeleeMode ? "Melee Mode" : "Magic (Shotgun) Mode";
        }
    }
}
