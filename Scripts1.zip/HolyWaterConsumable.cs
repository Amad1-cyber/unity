using System.Collections;
using UnityEngine;

namespace FPSRetroKit
{
    public class HolyWaterConsumable : MonoBehaviour
    {
        [Header("Holy Water Settings")]
        [Tooltip("Maximum number of uses for this holy water bottle.")]
        public int maxUses = 5;
        private int remainingUses;

        [Header("Time Limit Settings")]
        [Tooltip("Time (in seconds) the holy water is valid once activated (e.g., 120 seconds).")]
        public float timeLimit = 120f;
        private float timer = 0f;

        [Header("Input Settings")]
        [Tooltip("Key used to drink the holy water (default: K).")]
        public KeyCode drinkKey = KeyCode.K;

        [Header("Animation Settings")]
        [Tooltip("SpriteRenderer used for the drinking animation (this should be on your holy water item/panel).")]
        public SpriteRenderer spriteRenderer;
        [Tooltip("Array of sprites for the drinking animation flipbook.")]
        public Sprite[] drinkSprites;
        [Tooltip("Time each frame is displayed during the drinking animation.")]
        public float frameTime = 0.1f;
        [Tooltip("Idle sprite for the holy water when not drinking.")]
        public Sprite idleSprite;

        [Header("Restoration Settings")]
        [Tooltip("If true, fully restore health and mana when drinking.")]
        public bool restoreFull = true;

        [Header("Sound Settings")]
        [Tooltip("Sound to play when drinking holy water.")]
        public AudioClip drinkSound;

        private AudioSource audioSource;

        void Start()
        {
            remainingUses = maxUses;
            timer = 0f;
            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
                audioSource = gameObject.AddComponent<AudioSource>();

            // Set the sprite to idle initially.
            if (spriteRenderer != null && idleSprite != null)
            {
                spriteRenderer.sprite = idleSprite;
            }
        }

        void Update()
        {
            // This script should be active only in Peace Mode.
            timer += Time.deltaTime;
            if (timer >= timeLimit)
            {
                Debug.Log("Holy water has expired due to time limit.");
                Destroy(gameObject);
                return;
            }

            // Listen for the drinking key.
            if (Input.GetKeyDown(drinkKey))
            {
                if (remainingUses > 0)
                {
                    StartCoroutine(Drink());
                }
                else
                {
                    Debug.Log("No more holy water uses remaining.");
                }
            }
        }

        private IEnumerator Drink()
        {
            Debug.Log("Drinking holy water...");

            // Play flipbook animation if sprites are assigned.
            if (spriteRenderer != null && drinkSprites != null && drinkSprites.Length > 0)
            {
                for (int i = 0; i < drinkSprites.Length; i++)
                {
                    spriteRenderer.sprite = drinkSprites[i];
                    yield return new WaitForSeconds(frameTime);
                }
                // Revert to idle sprite.
                spriteRenderer.sprite = idleSprite;
            }
            else
            {
                yield return new WaitForSeconds(0.5f);
            }

            // Play the drinking sound.
            if (drinkSound != null)
                audioSource.PlayOneShot(drinkSound);

            // Restore player's health and mana fully.
            PlayerHealth playerHealth = FindObjectOfType<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.RestoreHealth(9999);  // Adjust as needed to fully restore.
                playerHealth.RestoreMana(9999);
                Debug.Log("Holy water consumed: Health and Mana fully restored.");
            }
            else
            {
                Debug.LogWarning("PlayerHealth component not found.");
            }

            remainingUses--;
            Debug.Log("Remaining holy water uses: " + remainingUses);

            if (remainingUses <= 0)
            {
                Debug.Log("Holy water bottle is empty. Destroying object.");
                Destroy(gameObject);
            }
        }
    }
}
