using System.Collections;
using UnityEngine;

namespace FPSRetroKit
{
    public class HolyCigaretteConsumable : MonoBehaviour
    {
        [Header("Cigarette Settings")]
        [Tooltip("Maximum number of cigarettes available.")]
        public int maxUses = 5;
        private int remainingUses;

        [Header("Time Limit Settings")]
        [Tooltip("Time (in seconds) the holy cigarette item is valid once activated (optional). Set to 0 to disable time limit.")]
        public float timeLimit = 120f;
        private float timer = 0f;

        [Header("Input Settings")]
        [Tooltip("Key used to smoke the holy cigarette (default: G).")]
        public KeyCode smokeKey = KeyCode.G;

        [Header("Animation Settings")]
        [Tooltip("SpriteRenderer used to display the smoking animation.")]
        public SpriteRenderer spriteRenderer;
        [Tooltip("Array of sprites for the smoking animation flipbook (e.g., 8 sprites).")]
        public Sprite[] smokeSprites;
        [Tooltip("Time (in seconds) each frame is displayed during the smoking animation.")]
        public float frameTime = 0.1f;
        [Tooltip("Idle sprite for the cigarette when not being smoked.")]
        public Sprite idleSprite;

        [Header("Restoration Settings")]
        [Tooltip("Amount of mana restored per cigarette use.")]
        public float manaRestoreAmount = 50f;

        [Header("Sound Settings")]
        [Tooltip("Sound effect played when smoking the cigarette.")]
        public AudioClip smokeSound;

        private AudioSource audioSource;

        void Start()
        {
            remainingUses = maxUses;
            timer = 0f;
            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
                audioSource = gameObject.AddComponent<AudioSource>();

            // Set the idle sprite initially.
            if (spriteRenderer != null && idleSprite != null)
            {
                spriteRenderer.sprite = idleSprite;
            }
        }

        void Update()
        {
            // Optional time limit for cigarette validity.
            if (timeLimit > 0f)
            {
                timer += Time.deltaTime;
                if (timer >= timeLimit)
                {
                    Debug.Log("Holy cigarette has expired due to time limit.");
                    Destroy(gameObject);
                    return;
                }
            }

            // Listen for the smoking key.
            if (Input.GetKeyDown(smokeKey))
            {
                if (remainingUses > 0)
                {
                    StartCoroutine(SmokeCigarette());
                }
                else
                {
                    Debug.Log("No more holy cigarette uses remaining.");
                }
            }
        }

        private IEnumerator SmokeCigarette()
        {
            Debug.Log("Smoking holy cigarette...");

            // Play the flipbook animation if sprites are assigned.
            if (spriteRenderer != null && smokeSprites != null && smokeSprites.Length > 0)
            {
                for (int i = 0; i < smokeSprites.Length; i++)
                {
                    spriteRenderer.sprite = smokeSprites[i];
                    yield return new WaitForSeconds(frameTime);
                }
                // Revert to the idle sprite.
                spriteRenderer.sprite = idleSprite;
            }
            else
            {
                yield return new WaitForSeconds(0.5f);
            }

            // Play the smoking sound.
            if (smokeSound != null)
                audioSource.PlayOneShot(smokeSound);

            // Restore player's mana by a fixed amount.
            PlayerHealth playerHealth = FindObjectOfType<PlayerHealth>();
            if (playerHealth != null)
            {
                playerHealth.RestoreMana((int)manaRestoreAmount);
                Debug.Log("Holy cigarette smoked: Restored " + manaRestoreAmount + " Mana.");
            }
            else
            {
                Debug.LogWarning("PlayerHealth component not found.");
            }

            remainingUses--;
            Debug.Log("Remaining holy cigarette uses: " + remainingUses);

            if (remainingUses <= 0)
            {
                Debug.Log("Holy cigarette item is empty. Destroying item.");
                Destroy(gameObject);
            }
        }
    }
}
