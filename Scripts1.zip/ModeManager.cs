using UnityEngine;
using UnityEngine.UI;

public enum Mode { Search, Melee, Magic }

public class ModeManager : MonoBehaviour
{
    public Text modeText;
    public Mode currentMode = Mode.Search;

    void Start()
    {
        UpdateModeUI();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            currentMode = Mode.Search;
            UpdateModeUI();
        }
        else if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            currentMode = Mode.Melee;
            UpdateModeUI();
        }
        else if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            currentMode = Mode.Magic;
            UpdateModeUI();
        }

        // Scroll wheel example:
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0)
        {
            int next = (int)currentMode + (scroll > 0 ? 1 : -1);
            if (next < 0) next = 2;
            if (next > 2) next = 0;
            currentMode = (Mode)next;
            UpdateModeUI();
        }
    }

    private void UpdateModeUI()
    {
        if (modeText == null) return;

        switch (currentMode)
        {
            case Mode.Search:
                modeText.text = "Search Mode";
                break;
            case Mode.Melee:
                modeText.text = "Melee Mode";
                break;
            case Mode.Magic:
                modeText.text = "Magic Mode";
                break;
        }
    }
}
