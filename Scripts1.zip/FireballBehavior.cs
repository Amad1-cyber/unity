﻿using UnityEngine;

namespace FPSRetroKit
{
    public class FireballBehavior : MonoBehaviour
    {
        public int damage = 25;

        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Enemy"))
            {
                Debug.Log("Fireball hit " + other.name + " for " + damage + " damage.");
                other.gameObject.SendMessage("TakeDamage", damage, SendMessageOptions.DontRequireReceiver);
                Destroy(gameObject);
            }
        }
    }
}
